# plugin.audio.spotlight

Spotlight Kodi Plugin
---

Forked from https://bitbucket.org/re/spotlight

ChangeLog
---

* 20150602 now works on raspberry pi 2 (armv7) with armv6hf libspotify
