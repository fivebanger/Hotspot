'''
Copyright 2011 Mikel Azkolain

This file is part of Spotimc.

Spotimc is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Spotimc is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Spotimc.  If not, see <http://www.gnu.org/licenses/>.
'''


import os
import os.path
import xbmc
import xbmcgui
import threading
import gc
import traceback
import weakref
import re
from spotify import MainLoop, ConnectionState, ErrorType, Bitrate, playlistcontainer
from spotify import track as _track
from spotify.session import Session, SessionCallbacks
from spotifyproxy.httpproxy import ProxyRunner
from spotifyproxy.audio import BufferManager
from taskutils.decorators import run_in_thread
from taskutils.threads import TaskManager
from threading import Event
from settings import SettingsManager, CacheManagement, StreamQuality, \
    GuiSettingsReader, InfoValueManager
from __main__ import __addon_version__, __addon_path__, __addon_id__
from logs import get_logger, setup_logging
#hmk from utils.gui import hide_busy_dialog, show_busy_dialog
import time
import json

try:
    from appkey import appkey
except:
    xbmc.log( 'Hotspot: No valid appkey found', xbmc.LOGERROR )
    exit()



class Application:
    __vars = None

    def __init__(self):
        self.__vars = {}

    def set_var(self, name, value):
        self.__vars[name] = value

    def has_var(self, name):
        return name in self.__vars

    def get_var(self, name):
        return self.__vars[name]

    def remove_var(self, name):
        del self.__vars[name]


class HotspotCallbacks(SessionCallbacks):
    __mainloop = None
    __audio_buffer = None
    __logout_event = None
    __app = None
    __logger = None
    __log_regex = None

    def __init__(self, mainloop, audio_buffer, app):
        self.__mainloop = mainloop
        self.__audio_buffer = audio_buffer
        self.__app = app
        self.__logger = get_logger()
        self.__log_regex = re.compile('[0-9]{2}:[0-9]{2}:[0-9]{2}'
                                      '\.[0-9]{3}\s(W|I|E)\s')
        self.__app.set_var('player_is_playing', False)

    def logged_in(self, session, error_num):
        #Log this event
        #self.__logger.debug('logged in: {0:d}'.format(error_num))
        return

        #Store last error code
        self.__app.set_var('login_last_error', error_num)

        #Take action if error status is not ok
        if error_num != ErrorType.Ok:
            self.__app.get_var('connstate_event').set()

    def logged_out(self, session):
        #self.__logger.debug('logged out')
        self.__app.get_var('logout_event').set()
        return

    def connection_error(self, session, error):
        self.__app.set_var('connection_error', True)
        #self.__logger.error('connection error: {0:d}'.format(error))

    def message_to_user(self, session, data):
        #self.__logger.info('message to user: {0}'.format(data))
        return

    def _get_log_message_level(self, message):
        matches = self.__log_regex.match(message)
        if matches:
            return matches.group(1)

    def log_message(self, session, data):
        message_level = self._get_log_message_level(data)
        if message_level == 'I':
            #self.__logger.info(data)
            return
        elif message_level == 'W':
            #self.__logger.warning(data)
            return
        else:
            #self.__logger.error(data)
            return

    def streaming_error(self, session, error):
        #self.__logger.info('streaming error: {0:d}'.format(error))
        xbmc.log( 'Hotspot: Streaming error', xbmc.LOGERROR)
        return

    @run_in_thread
    def play_token_lost(self, session):
        #get track id
        track = self.__audio_buffer.get_track()
        track = str(track).split(':')
        track = track[2]

        #Cancel the current buffer
        self.__audio_buffer.stop()        
        self.__audio_buffer.cleanup()
        
        player = xbmc.Player()
        is_playing = player.getPlayingFile()
        
        #don't annoy user if Spotify is not playing 
        if ('is_playing_xbmcstubs' in is_playing) or (track in is_playing):
            if self.__app.has_var('playlist_manager'):
                self.__app.get_var('playlist_manager').stop(False)
            else:
                #xbmc.executebuiltin('PlayerControl(stop)')
                player.stop()
                dlg = xbmcgui.Dialog()
                dlg.ok('Playback stopped', 'This Spotify account is in use on another device.')

    def end_of_track(self, session):
        self.__audio_buffer.set_track_ended()

    def notify_main_thread(self, session):
        self.__mainloop.notify()

    def music_delivery(self, session, data, num_samples, sample_type,
                       sample_rate, num_channels):
        return self.__audio_buffer.music_delivery(
            data, num_samples, sample_type, sample_rate, num_channels)

    def connectionstate_changed(self, session):
        #Set the apropiate event flag, if available
        self.__app.get_var('connstate_event').set()


class MainLoopRunner(threading.Thread):
    __mainloop = None
    __session = None
    __proxy = None

    def __init__(self, mainloop, session):
        threading.Thread.__init__(self)
        self.__mainloop = mainloop
        self.__session = weakref.proxy(session)

    def run(self):
        self.__mainloop.loop(self.__session)

    def stop(self):
        self.__mainloop.quit()
        self.join(10)


def get_audio_buffer_size():
    #Base buffer setting will be 10s
    buffer_size = 10

    try:
        reader = GuiSettingsReader()
        value = reader.get_setting('settings.musicplayer.crossfade')
        buffer_size += int(value)

    except:
        xbmc.log(
            'Failed reading crossfade setting. Using default value.',
            xbmc.LOGERROR
        )

    return buffer_size


def check_dirs():
    addon_data_dir = os.path.join(
        xbmc.translatePath('special://profile/addon_data'),
        __addon_id__
    )

    #Auto-create profile dir if it does not exist
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)

    #Libspotify cache & settings
    sp_cache_dir = os.path.join(addon_data_dir, 'libspotify/cache')
    sp_settings_dir = os.path.join(addon_data_dir, 'libspotify/settings')

    if not os.path.exists(sp_cache_dir):
        os.makedirs(sp_cache_dir)

    if not os.path.exists(sp_settings_dir):
        os.makedirs(sp_settings_dir)

    return (addon_data_dir, sp_cache_dir, sp_settings_dir)


def set_settings(settings_obj, session):
    #If cache is enabled set the following one
    if settings_obj.get_cache_status():
        if settings_obj.get_cache_management() == CacheManagement.Manual:
            cache_size_mb = settings_obj.get_cache_size() * 1024
            session.set_cache_size(cache_size_mb)

    #Bitrate config
    br_map = {
        StreamQuality.Low: Bitrate.Rate96k,
        StreamQuality.Medium: Bitrate.Rate160k,
        StreamQuality.High: Bitrate.Rate320k,
    }
    session.preferred_bitrate(br_map[settings_obj.get_audio_quality()])

    #And volume normalization
    session.set_volume_normalization(settings_obj.get_audio_normalize())

    #And volume normalization
    session.set_volume_normalization(settings_obj.get_audio_normalize())



def keyboardText(heading = 'Enter phrase', hidden=False):
    keyboard = xbmc.Keyboard('', heading)
    keyboard.setHiddenInput(hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
    
    return ''


def do_login(session, script_path, skin_dir, app):
    #Get the last error if we have one
    if app.has_var('login_last_error'):
        prev_error = app.get_var('login_last_error')
    else:
        prev_error = 0

    #If no previous errors and we have a remembered user
    if prev_error == 0 and session.remembered_user() is not None:
    #if prev_error == 1 and session.remembered_user() is not None:
        session.relogin()
        status = True
    #Otherwise let's do a normal login process
    else:
        username = keyboardText(heading='Enter Username')
        password = keyboardText(heading='Enter Password', hidden=True)

        remember_set = True
        session.login(username, password, remember_set)
        
        status = True
    return status


def login_get_last_error(app):
    if app.has_var('login_last_error'):
        return app.get_var('login_last_error')
    else:
        return 0


def wait_for_connstate(session, app, state):

    #Store the previous login error number
    last_login_error = login_get_last_error(app)

    #Add a shortcut to the connstate event
    cs = app.get_var('connstate_event')

    #Wrap all the tests for the following loop
    def continue_loop():

        #Get the current login error
        cur_login_error = login_get_last_error(app)
        
        #stop loop on connection errors
        if app.get_var('connection_error'):
            #print 'connection error'
            return 0

        #Continue the loop while these conditions are met:
        #  * An exit was not requested
        #  * Connection state was not the desired one
        #  * No login errors where detected
        return (
            not app.get_var('exit_requested') and
            session.connectionstate() != state and (
                last_login_error == cur_login_error or
                cur_login_error == ErrorType.Ok
            )
        )

    #Keep testing until conditions are met
    while continue_loop():
        cs.wait(5)
        cs.clear()
    
    retval = session.connectionstate() == state
    return retval


def show_busy_dialog():
    xbmc.executebuiltin('ActivateWindow(busydialog)')


def hide_busy_dialog():
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    while xbmc.getCondVisibility('Window.IsActive(busydialog)'):
        time.sleep(.1)



class PlaylistContainerCallbacks(playlistcontainer.PlaylistContainerCallbacks):
    _checker = None
    
    
    def __init__(self, checker):
        self._checker = checker
    
    
    def container_loaded(self, container):
        self._checker.check_conditions()
        

class ProxyCallbacks(object):
    
    def __init__(self):
        self.track_id = ''
    
    
    def on_stream_started(self, track):
        track_id = str(track).split(':')
        track_id = track_id[2]
        
        if self.track_id != track_id:
            xbmc.executebuiltin('XBMC.RunPlugin(plugin://'+__addon_id__+'/?mode=on_play_song&track_id='+track_id+')')
            self.track_id = track_id
            
    
    def on_stream_ended(self):
        return
 
         
def start(addon_dir):
    
    show_busy_dialog()  #hmk
    
    #Initialize app var storage
    app = Application()
    logout_event = Event()
    connstate_event = Event()
    info_value_manager = InfoValueManager()
    app.set_var('logout_event', logout_event)
    app.set_var('login_last_error', ErrorType.Ok)
    app.set_var('connstate_event', connstate_event)
    app.set_var('exit_requested', False)
    app.set_var('info_value_manager', info_value_manager)
    app.set_var('connection_error', False)

    #Check needed directories first
    data_dir, cache_dir, settings_dir = check_dirs()

    #Instantiate the settings obj
    settings_obj = SettingsManager()

    #Initialize spotify stuff
    ml = MainLoop()
    buf = BufferManager(get_audio_buffer_size())
    callbacks = HotspotCallbacks(ml, buf, app)
    sess = Session(
        callbacks,
        app_key=appkey,
        user_agent="python ctypes bindings",
        settings_location=settings_dir,
        cache_location=cache_dir,
        initially_unload_playlists=False,
    )

    #Now that we have a session, set settings
    set_settings(settings_obj, sess)

    #Initialize libspotify's main loop handler on a separate thread
    ml_runner = MainLoopRunner(ml, sess)
    ml_runner.start()

    #Set the exit flag if login was cancelled
    if not do_login(sess, addon_dir, "DefaultSkin", app):
        app.set_var('exit_requested', True)

    #Otherwise block until state is sane, and continue
    elif wait_for_connstate(sess, app, ConnectionState.LoggedIn):
        
        proxy_port = settings_obj.get_misc_server_port()
        proxy_runner = ProxyRunner(sess, buf, host='127.0.0.1')
        retval = proxy_runner.open(host='127.0.0.1', port=proxy_port)
        if True == retval:
            proxy_runner.start()    #just start and come back
            #proxy_runner.run()      #run forever and never come back
            log_str = 'starting proxy at port {0}'.format(proxy_runner.get_port())
            #print log_str
            
            pcb = ProxyCallbacks()
            proxy_runner.set_stream_start_callback(pcb.on_stream_started)
            proxy_runner.set_stream_end_callback(pcb.on_stream_ended)
            
            get_token = proxy_runner.get_user_token('Hotspot')
            #print get_token
            get_port = proxy_runner.get_port()
            #print get_port
            get_host = proxy_runner.get_host()
            #print get_host
        
            hide_busy_dialog()
            
            # wait in case we are running in console
            time.sleep(5)
                
            #Stay on the application until told to do so
            while not xbmc.abortRequested:
            #while True:
                time.sleep(.2)
    
            app.set_var('exit_requested', True)
            xbmc.log( 'Hotspot: Clean up and exit proxy', xbmc.LOGNOTICE )
            
            #Playback and proxy deinit sequence
            proxy_runner.clear_stream_end_callback()
            proxy_runner.clear_stream_start_callback()
            proxy_runner.stop()
        else:
            xbmc.log( 'Hotspot: Proxy port already in use', xbmc.LOGERROR )
            dlg = xbmcgui.Dialog()
            dlg.ok('Error', 'Hotspot server port already in use.')
    else:
        # connection error
        pass
    
    hide_busy_dialog()
    
    #start general clean up
    buf.cleanup()
    
    #Join all the running tasks
    tm = TaskManager()
    tm.cancel_all()
    
    #Clear some vars and collect garbage
    proxy_runner = None
    preloader_cb = None
    playlist_manager = None
    mainwin = None
    gc.collect()
    
    #Logout
    if sess.user() is not None:
        sess.logout()

    #Stop main loop
    ml_runner.stop()

    #Some deinitializations
    info_value_manager.deinit()

def main():

    setup_logging()

    #And perform the rest of the import statements
    from environment import set_dll_paths
    from _spotify import unload_library

    #Add the system specific library path
    set_dll_paths('resources/dlls')

    #Load & start the actual gui, no init code beyond this point
    start(__addon_path__)
