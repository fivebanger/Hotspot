import xbmc

class Keyboard():
    
    def __init__(self):
        pass
    
    def get_text(self, heading='', text='', hidden=False):
        keyboard = xbmc.Keyboard(text, heading)
        keyboard.setHiddenInput(hidden)
        keyboard.doModal()
        if keyboard.isConfirmed():
            return keyboard.getText()
        
        return ''