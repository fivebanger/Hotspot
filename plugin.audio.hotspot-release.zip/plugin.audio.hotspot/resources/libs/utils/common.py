
import xbmc


def is_playing():
    player = xbmc.Player()
    is_playing = player.getPlayingFile()
    
    #check if xbmc player is playing hotspot/spotify
    if 'User-Agent=Hotspot' in is_playing:
        return True
    else:
        return False