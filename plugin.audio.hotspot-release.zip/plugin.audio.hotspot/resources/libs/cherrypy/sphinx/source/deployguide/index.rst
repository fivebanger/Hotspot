****************
Deployment Guide
****************

Servers
=======

.. toctree::
   :maxdepth: 2

   apache
   /refman/process/servers
   /refman/wsgiserver/init


Environment
===========

.. toctree::
   :maxdepth: 2

   cherryd
   /refman/process/plugins/daemonizer
   /refman/process/plugins/dropprivileges
   /refman/process/plugins/pidfile
   /refman/process/plugins/signalhandler


