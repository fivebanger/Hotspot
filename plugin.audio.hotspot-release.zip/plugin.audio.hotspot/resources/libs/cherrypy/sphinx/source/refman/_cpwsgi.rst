***********************
:mod:`cherrypy._cpwsgi`
***********************

.. automodule:: cherrypy._cpwsgi

Classes
=======

.. autoclass:: VirtualHost
   :members:

.. autoclass:: InternalRedirector
   :members:

.. autoclass:: ExceptionTrapper
   :members:

.. autoclass:: AppResponse
   :members:

.. autoclass:: CPWSGIApp
   :members:

