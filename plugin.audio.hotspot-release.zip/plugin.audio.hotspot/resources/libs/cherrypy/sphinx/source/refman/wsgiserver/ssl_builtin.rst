*****************************************************
:mod:`cherrypy.wsgiserver.ssl_builtin` -- Builtin SSL
*****************************************************

.. automodule:: cherrypy.wsgiserver.ssl_builtin

Classes
=======

.. autoclass:: BuiltinSSLAdapter
   :members:

