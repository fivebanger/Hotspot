

class DispatcherAdd():
    
    def __init__(self, base_url, addon_handle, addon_args):
        self.base_url = base_url
        self.addon_handle = addon_handle
        self.addon_args = addon_args
    
    def route(self):        
        return False
