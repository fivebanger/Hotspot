
class ContextmenuAdd():
    
    def __init__(self):
        pass
    
    def append(self, type, base_url, ContextMenueItems, add=False, remove=False, artist_id='', album_id='', id='', album_name='', icon='', user=''):
        return