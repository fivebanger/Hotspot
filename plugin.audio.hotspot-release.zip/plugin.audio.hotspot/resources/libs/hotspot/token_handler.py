
import os
import xbmcaddon
import xbmcvfs
import xbmc
import xbmcgui
import json
import dirs
import socket
from spotipy import oauth2
from oauth_server import OAuthServer
        
        
class TokenHandler(object):
    
    def __init__(self, token_name='token.jsn'):
        addon_id   = 'plugin.audio.hotspot'
        self.addon = xbmcaddon.Addon(addon_id)
        
        self.cl_id  = self.addon.getSetting('client_id')
        self.cl_sec = self.addon.getSetting('client_secret')
        self.port   = self.addon.getSetting('oauth_server_port')
        
        self.name = token_name
        self.path = dirs.check_addon_data_path()
        return
    
    
    def get_token(self):
        new_token = False

        while True:
            cache_path = self.get_token_path()
            if None != cache_path:
                token =  self._get_token(cache_path)
                if None != token:
                    return token
        
            if False == new_token:  
                new_token = True 
                xbmc.log( 'Hotspot: No valid Spotify token', xbmc.LOGERROR )
                dlg = xbmcgui.Dialog()
                retval = dlg.yesno('Token error', 'No valid token found. Start authentication process?', nolabel='start', yeslabel='cancel')
            
                if True == retval: 
                    #cancel
                    exit()
    
            self._generate_token()
    
    
    def _get_token(self, cache_path):
        cache_path = self.get_token_path()
        scope = self.get_token_scope()
        
        auth = oauth2.SpotifyOAuth(self.cl_id, self.cl_sec, '', None, scope, cache_path)
        token_info = auth.get_cached_token()
    
        token = None
        if None != token_info:
            token = token_info['access_token']
        
        return token
    
    
    def _update_client_dat(self):
        error = False
        file  = os.path.join(self.path, self.name)
        
        try:
            fh     = xbmcvfs.File(file)
            dat    = fh.read()
            result = json.loads(dat)
            fh.close()
        except:
            dat   = None
            error = True
            xbmc.log( 'Hotspot: Update error. Cannot load %s' %file, xbmc.LOGERROR )

        if None != dat:
            try:
                self.addon.setSetting('client_id', result['client_id'])
                self.addon.setSetting('client_secret', result['client_secret'])
            except:
                error = True
                xbmc.log( 'Hotspot: Update error. No client data found. %s' %file, xbmc.LOGERROR )

        return error
    
    
    def _generate_token(self):
    
        sp_host = socket.gethostname()
        sp_host = sp_host.lower()
        sp_port = int(self.port)
        sp_block = False
        
        base_uri = 'http://%s:%s' %(sp_host, sp_port)
        redirect_uri = base_uri + '/callback'
        
        #check if current port is already open
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex(('127.0.0.1', sp_port))
        
        if result == 0:
            #port already in use
            dlg = xbmcgui.Dialog()
            dlg.ok('Hotspot error', 'OAuth server port already in use.')
            exit()
        
        sp = OAuthServer(sp_port) 
        #sp.set_credentials(client_id, client_secret, redirect_uri)
        sp.set_redirect_uri(redirect_uri)
        sp.set_token_path(self.path, self.name)
        sp.set_cb_end_html(self._end_html_page)
        sp.start(sp_block)

        #host = socket.gethostbyname(host)
        dlg = xbmcgui.Dialog()
        retval = dlg.yesno('Authentication process', '%s' %(base_uri), '','Open this link in a browser within your LAN', nolabel='ok', yeslabel='cancel')
        
        sp.stop()
            
        if True == retval: 
            #cancel
            exit()
        
        self._update_client_dat()
    
        return
    
    
    def _end_html_page(self):
        return """
        <html>
          <head>
          </head>
          <body>
            <p>Your token was added to the Hotspot add-on. Use Import/Export function from Hotspot add-on settings to impor/export your token to another Hotspot instance</p>
            <br>
            Go to add-on settings if you want to export/import your token to another Hotspot instance.
            <br><br>
            <p>Please note:</p>
            <p>Keep your account data secret. Never share your token, Cient ID or Client secret with someone else.
            <br>
            These information belongs to your account and may abused by other persons.</p>
            <br>
            <br>
            <p>You can also export your token for back-up or importing to another Hotspot instance now:</p>
            <form method="get" action="export_token">
              <button type="submit">Export</button><br><br><br>
            </form>
            <form method="get" action="stop">
              <p>Exit:</p>
              <button type="submit">Exit</button><br><br><br>
            </form>
          </body>
        </html>
        """
    
    
    def export_token(self, export_path):
        error = True
        file  = self.get_token_path()
        
        try:
            fh     = xbmcvfs.File(file)
            dat    = fh.read()
            result = json.loads(dat)
            fh.close()
        except:
            dat = None
            xbmc.log( 'Hotspot: Export error. Cannot load %s' %file, xbmc.LOGERROR )
            dlg = xbmcgui.Dialog()
            dlg.ok('Hotspot export error', 'No token found.')
            
        file = os.path.join(export_path, self.name)
        if None != dat:
            try:
                result['client_id']     = self.addon.getSetting('client_id')
                result['client_secret'] = self.addon.getSetting('client_secret')
                
                fh  = xbmcvfs.File(file, 'w')
                dat = json.dumps(result) 
                fh.write(dat)
                fh.close()
                error = False
            except:
                xbmc.log( 'Hotspot: Cannot write %s' %file, xbmc.LOGERROR )
                dlg = xbmcgui.Dialog()
                dlg.ok('Hotspot error', 'Cannot export token.')
                
        if False == error:
            dlg = xbmcgui.Dialog()
            dlg.ok('Token export', 'Token exported to %s' %export_path)

        return
    
    
    def import_token(self, import_file):
        error = True
        
        try:
            fh     = xbmcvfs.File(import_file)
            dat    = fh.read()
            result = json.loads(dat)
            fh.close()
        except:
            dat = None
            xbmc.log( 'Hotspot: Import error. Cannot load %s' %import_file, xbmc.LOGERROR )
            dlg = xbmcgui.Dialog()
            dlg.ok('Hotspot import error', 'Cannot import token.')
            
        file = os.path.join(self.path, self.name)
        if None != dat:
            try:
                self.addon.setSetting('client_id', result['client_id'])
                self.addon.setSetting('client_secret', result['client_secret'])
                
                fh   = xbmcvfs.File(file, 'w')
                fh.write(dat)
                fh.close()
                error = False
            except:
                xbmc.log( 'Hotspot: Cannot import %s' %file, xbmc.LOGERROR )
                dlg = xbmcgui.Dialog()
                dlg.ok('Hotspot error', 'Cannot parse token.')
                
        if False == error:
            dlg = xbmcgui.Dialog()
            dlg.ok('Token export', 'Token successfully imported.')

        return
    
    
    def get_token_path(self):
        file = os.path.join(self.path, self.name)
        
        if not os.path.exists(file):
            file = None
        
        return file

    
    def get_token_scope(self):
        scope  = ''
        result = None
        file   = self.get_token_path()
        
        try:
            fh     = xbmcvfs.File(file)
            result = json.loads( fh.read() )
            fh.close()
        except:
            xbmc.log( 'Hotspot: Scope error: Cannot load %s' %file, xbmc.LOGERROR )
                
        if None != result:
            try:
                scope  = result['scope']
            except:
                xbmc.log( 'Hotspot: Error parsing token file, no scope', xbmc.LOGERROR )
            
        return scope
    