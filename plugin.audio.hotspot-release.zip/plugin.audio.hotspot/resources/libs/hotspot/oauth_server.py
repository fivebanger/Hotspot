

import os
import sys
import time
import json
import cherrypy
from spotipy import oauth2



class OAuthServer(object):
    
    def __init__(self, port, log=False):
        self.port = port
        self.log  = log
        self.run  = False
        
        self.cl_id    = ''
        self.cl_sec   = ''
        self.redirect = None
        self.cb_end   = None
        
        self.path = None
        self.file = 'spotify_token.txt'
        
        self.scope = None
            
        return
    
        
    def start(self, block=True):
        
        if None == self.path:
            self.path = os.path.dirname(os.path.realpath(__file__))
            self.path = os.path.join(self.path, 'cache')
        
        if not os.path.exists(self.path):
            os.makedirs(self.path)
            
        if None == self.redirect:
            self.redirect = 'http://localhost:%s/callback' %(self.port)
            
        self.rh = SpotifyRequestHandler(self.port, self.stop, self.path, self.file, self.redirect)
        
        #init the request handler
        self.rh.set_credentials(self.cl_id, self.cl_sec)
        self.rh.set_scope(self.scope)
        self.rh.set_cb_end_html(self.cb_end)
        
        # allow requests from all ip addresses (otherwise only localhost is allowed)
        cherrypy.server.socket_host = '0.0.0.0'
        # set port
        cherrypy.server.socket_port = self.port
           
        # start server
        config = {"/files":
                   {"tools.staticdir.on": True,
                    "tools.staticdir.dir": self.path
                   }
                 }
        cherrypy.tree.mount(self.rh, "/", config=config)
        
        if False == self.log:
            #Don't log to the screen by default
            log = cherrypy.log
            log.access_file = ''
            log.error_file = ''
            log.screen = False
        
        cherrypy.engine.start()
        self.run = True
        
        if( True == block ):
            while(self.run):
                time.sleep(0.1)

        return

    def stop(self):
        if( True == self.run ):
            cherrypy.engine.stop()     
            cherrypy.engine.exit()                
            self.run = False
        return


    def set_credentials(self, cl_id, cl_sec):
        self.cl_id  = cl_id
        self.cl_sec = cl_sec
        return


    def set_redirect_uri(self, redirect):
        if False == self.run:
            self.redirect = redirect
            return True
        
        return False


    def set_token_path(self, path, filename):
        if False == self.run:
            self.path = path
            self.file = filename
            return True
        
        return False


    def set_cb_end_html(self, cb_html_code):
        self.cb_end = cb_html_code
        return


    def set_scope(self, scope):
        self.scope = scope
        return
    
    
class SpotifyRequestHandler(object):

    """ Cherrypy request handler class. """
    
    def __init__(self, port, cb_stop, path, file, redirect, name='OAuthServer'):
        self.cl_id    = ''
        self.cl_sec   = ''
        self.redirect = redirect
        self.cb_end   = None
        
        self.path   = path
        self.file   = file
        self.c_file = None
        
        self.scope = None
        
        self.cb_stop  = cb_stop
        self.port     = port
        self.sp_oauth = None
        self.code     = ''
        self.error    = ''
        self.state    = ''
        
        self.server_name = name
        return

    def set_credentials(self, cl_id, cl_sec):
        self.cl_id  = cl_id
        self.cl_sec = cl_sec
        return


    def set_scope(self, scope):
        self.scope = scope
        return


    def set_cb_end_html(self, cb_html_code):
        self.cb_end = cb_html_code
        return
        
        
    def _get_token_info(self):
        
        if ('' == self.cl_id) and ('' == self.cl_sec) or ('' == self.redirect):
            return None
        
        if None == self.scope:
            scope = "playlist-read-private playlist-read-collaborative playlist-modify-public playlist-modify-private user-follow-modify user-follow-read user-library-read user-library-modify user-read-private user-read-email user-read-birthdate user-top-read"
        else:
            scope = self.scope
            
        self.c_file = os.path.join(self.path, self.file)
        

        self.sp_oauth = oauth2.SpotifyOAuth( self.cl_id, self.cl_sec, self.redirect, 
                                             scope=scope, cache_path=self.c_file )
    
        # try to get a valid token for this user, from the cache,
        # if not in the cache, then create a new (this will send
        # the user to a web page where they can authorize this app)
    
        token_info = self.sp_oauth.get_cached_token()
        
        if None != token_info:            
            #add client id and client secret
            token_info['client_id'] = self.cl_id
            token_info['client_secret'] = self.cl_sec
            
            f = open(self.c_file, 'w')
            f.write(json.dumps(token_info))
            f.close()
    
        return token_info
    
    
    def _error(self, text='Error'):
        return """
        <html>
          <head>
          </head>
          <body>
            <form method="get" action="index">
              <p>"""+text+"""</p>
              <button type="submit">Home</button><br><br><br>
            </form>
          </body>
        </html>"""
    
    
    def _end(self, text='exit:'):
        if self.cb_end:
            return self.cb_end()
        else:
            return self.index()
    
    
    @cherrypy.expose
    def export_token(self):

        if ('' != self.cl_id) and ('' != self.cl_sec):
            token_info = self._get_token_info()
            
            #add client id and client secret
            token_info['client_id'] = self.cl_id
            token_info['client_secret'] = self.cl_sec
            
            f = open(self.c_file, 'w')
            f.write(json.dumps(token_info))
            f.close()
            
            retval = """
            <html>
              <head>
              </head>
              <body>
                <a href="/files/"""+self.file+"""\" download>Download token</a><br><br><br>
                <form method="get" action="index">
                  <button type="submit">back</button><br><br><br>
                </form>
              </body>
            </html>"""
        else:
            retval = self._error('Error while exporting token.')
        
        return retval
        
        
    @cherrypy.expose
    def import_token(self):
        return """
        <html>
          <body>
            <form method="post" action="upload" enctype="multipart/form-data">
              Select a valid token file to import:<br><br>
              <input type="file" name="myFile"/>
              <br><br>
              <input type="submit" />
            </form>
            <br>
            <form method="get" action="index">
              <button type="submit">cancel</button><br><br>
            </form>
          </body>
        </html>
        """


    @cherrypy.expose
    def upload(self, myFile):
        retval = self._error('Import error')
        
        if myFile.file:
            lcHDRS = {}
            for key, val in cherrypy.request.headers.iteritems():
                lcHDRS[key.lower()] = val
        
            incomingBytes = int(lcHDRS['content-length'])
            content = myFile.file.read(incomingBytes)
            token_info = json.loads(content)
            
            if token_info.get('client_id') and token_info.get('client_secret'):            
                #get client id and client secret
                self.cl_id = token_info['client_id']
                self.cl_sec = token_info['client_secret']
                
                file = os.path.join(self.path, self.file) 
                fh   = open (file, "w")
                fh.write(content)
                fh.close()
                
                token_info = self._get_token_info()
                
                if None != token_info:
                    #token validated: token is valid
                    retval = self._end()
                else:
                    retval = self._error('Import error: Token not valid')

        return retval


    @cherrypy.expose
    def generate_token(self, cl_id='', cl_sec='', redirect=''):
        url = 'index'
        
        if ('' != cl_id) and ('' != cl_sec):
            self.cl_id  = cl_id
            self.cl_sec = cl_sec
        if ('' != redirect):
            self.redirect = redirect

        if ('' == self.cl_id) or ('' == self.cl_sec) or ('' == self.redirect):
            url = 'error_no_credentials'
        else:
            token_info = self._get_token_info()
            if None == token_info:
                url = self.sp_oauth.get_authorize_url()
            
        return self._redirect(url)
    
    
    def _redirect(self, url):
        
        if ('' == url) or (None == url):
            url = 'index'
        
        return """
            <!DOCTYPE HTML>
            <html lang="en-US">
                <head>
                    <meta charset="UTF-8">
                    <meta http-equiv="refresh" content="1; url="""+url+"""\"">
                    <script type="text/javascript">
                        window.location.href = \""""+url+"""\"
                    </script>
                    <title>Page Redirection</title>
                </head>
                <body>
                    <!-- Note: don't tell people to `click` the link, just tell them that it is a link. -->
                    If you are not redirected automatically, follow this <a href='"""+url+"""'>link to example</a>.
                </body>
            </html>
            """
    
    
    # Expose the index method through the web. CherryPy will never
    # publish methods that don't have the exposed attribute set to True.
    @cherrypy.expose
    def index(self):
        # CherryPy will call this method for the root URI ("/") and send
        # its return value to the client. Because this is tutorial
        # lesson number 01, we'll just send something really simple.
        # How about...
        if self.cb_end:
            retval = self.cb_end()
        else:
            retval = """
            <html>
              <body>
                <p>Your token is valid.</p>
                <br>
                <br>
                <p>Please note:</p>
                <p>Keep your account data secret. Never share your token, Cient ID or Client secret with someone else.
                <br>
                These information belongs to your account and may abused by other persons.</p>
                <br>
                <br>
                <form method="get" action="export_token">
                  <p>Export token:</p>
                  <button type="submit">export token</button><br><br><br>
                </form>
              </body>
            </html>
            """
            
        token_info = self._get_token_info()
        
        if (None == token_info):
            text = 'No valid token found.'
        
            retval = """
            <html>
              <body>
                <p>"""+text+"""</p><br>
                <form method="get" action="generate_token">
                  <p>Generate a new token:</p>
                  <button type="submit">generate token</button><br><br>
                </form>
                <br>
                <form method="get" action="import_token">
                  <p>Imprt a valid token token:</p>
                  <button type="submit">import token</button><br>
                </form>
              </body>
            </html>
            """

        return retval
    
    
    @cherrypy.expose
    def name(self):
        return self.server_name
    
    
    @cherrypy.expose
    def error_no_credentials(self):
        retval = """
        <html>
          <head>
          </head>
          <body>
            <p></p>
            Open 
            <a target="_blank" href="https://developer.spotify.com/my-applications/#!/applications/">Spotify applications</a>
            and get your Client ID and Client Secret or
            <a target="_blank" href="https://developer.spotify.com/my-applications/#!/applications/create">create an app</a>
            <br><br>
            <p>If creating a new application you can provide (or anything else you like...):</p>
            <p>Application Name: MySpotifyApp</p>
            <p>Description: MySpotifyApp</p>
            <br>
            """
        if None != self.redirect:
            retval = retval + """
              <p>Add this URI to your application's Redirect URIs (don't forget to press "save" button at end of page):</p>"""+self.redirect+"""
              <br><br><br>
              """
        retval = retval + """
            <form method="get" action="generate_token">
              <p>Client ID:</p>
              <p><input type="text" value="" name="cl_id" /></p>
              <p>Client Secret:</p>
              <p><input type="text" value="" name="cl_sec" /></p>
              """
        if None == self.redirect:
            retval = retval + """
              <p>Redirect URI:</p>
              <p><input type="text" value="" name="redirect" /></p>
              """     
        retval = retval + """
              <br>
              <button type="submit">Submit</button>
            </form>
            <br><br>
            <form method="get" action="index">
              <button type="submit">cancel</button><br><br><br>
            </form>
          </body>
        </html>
        """
        
        return retval


    @cherrypy.expose
    def stop(self):        
        if( None != self.cb_stop ):
            self.cb_stop()
            
            return """
            <html>
              <head>
              </head>
              <body>
                <p>You can close this window.</p>
              </body>
            </html>
            """
        else:
            self._error('Error on sto: No callback defined.')
            

    @cherrypy.expose
    def callback(self, code='', error='', state=''):
        retval = self._error('Error while generating token. Error: %s, State: %s' %(error, state))
        
        self.code  = code
        self.error = error
        self.state = state
        
        if '' != code:
            self.sp_oauth.get_access_token(code)
            token_info = self._get_token_info()
            if token_info:
                # token is valid
                retval = self.cb_end()

        return retval
        