from url_utils import Urlbuild
from context_menu_add import ContextmenuAdd



class Contextmenu():
    
    def __init__(self, base_url):
        self.base_url = base_url
        
            
    def menu_item(self, type, name='', media='', id='', filename=''):
    
        ContextMenueItems = []
        
        url_create = Urlbuild(self.base_url)
        cm_add = ContextmenuAdd()

        if type == 'main_menu':
            if '' != name:
                url_menu = url_create.addon({'mode': 'update_fanart', 'type': media, 'filename': filename})
                ContextMenueItems.append(('Update '+name+' fanart', 'XBMC.RunPlugin('+url_menu+')'))
                
                if 'albums' == media:
                    url_menu = url_create.addon({'mode': 'import_saved_album', 'filename': filename})
                    ContextMenueItems.append(('Import My Spotify Albums', 'XBMC.RunPlugin('+url_menu+')'))
           
            url_menu = url_create.addon({'mode': 'category_add'})
            ContextMenueItems.append(('Add new category', 'XBMC.RunPlugin('+url_menu+')'))
           
            url_menu = url_create.addon({'mode': 'category_rename', 'name': name})
            ContextMenueItems.append(('Rename category', 'XBMC.RunPlugin('+url_menu+')'))
           
            url_menu = url_create.addon({'mode': 'category_delete', 'name': name})
            ContextMenueItems.append(('Delete category', 'XBMC.RunPlugin('+url_menu+')'))
           
            url_menu = url_create.addon({'mode': 'category_move', 'name': name})
            ContextMenueItems.append(('Move category', 'XBMC.RunPlugin('+url_menu+')'))

        elif type == 'spotify_menu':
            if '' != media:
                url_menu = url_create.addon({'mode': 'update_fanart', 'type': media, 'filename': 'none'})
                ContextMenueItems.append(('Update '+name+' fanart', 'XBMC.RunPlugin('+url_menu+')'))

        elif type == 'recently_menu':
            url_menu = url_create.addon({'mode': 'recently_items_play', 'type': 'played'})
            ContextMenueItems.append(('Play', 'XBMC.RunPlugin('+url_menu+')'))
            
        elif type == 'category_menu':
            url_menu = url_create.addon({'mode': 'recommend_genre', 'seed': id})
            ContextMenueItems.append(('Recommended albums', 'XBMC.Container.Refresh('+url_menu+')'))
                        
        return ContextMenueItems

 
    def artist_item(self, add=False, remove=False, artist_id='', filename=''):
        type = 'artists'
        ContextMenueItems = []
        
        url_create = Urlbuild(self.base_url)
        cm_add = ContextmenuAdd()

        url_menu = url_create.addon({'mode': 'show_artists_toptracks', 'artist_id': artist_id})
        ContextMenueItems.append(('Show artist\'s top tracks', 'XBMC.Container.Refresh('+url_menu+')'))
        
        url_menu = url_create.addon({'mode': 'show_artist_singles', 'artist_id': artist_id})
        ContextMenueItems.append(('Show artist\'s singles', 'XBMC.Container.Refresh('+url_menu+')'))
        
        url_menu = url_create.addon({'mode': 'show_artist_compilations', 'artist_id': artist_id})
        ContextMenueItems.append(('Show artist\'s compilations', 'XBMC.Container.Refresh('+url_menu+')'))
        
        url_menu = url_create.addon({'mode': 'show_artist_appears_on', 'artist_id': artist_id})
        ContextMenueItems.append(('Show appears on', 'XBMC.Container.Refresh('+url_menu+')'))
        
        url_menu = url_create.addon({'mode': 'show_related_artists', 'artist_id': artist_id})
        ContextMenueItems.append(('Show related artists', 'XBMC.Container.Refresh('+url_menu+')'))
            
        url_menu = url_create.addon({'mode': 'recommend_albums', 'seed': artist_id})
        ContextMenueItems.append(('Recommended albums', 'XBMC.Container.Refresh('+url_menu+')'))
        
        if add == True:                
            url_menu = url_create.addon({'mode': 'category_add_item', 'type': type, 'id': artist_id})
            #ContextMenueItems.append(('Add artist to list', 'XBMC.RunPlugin('+url_menu+')'))
        
        if '' != artist_id:
            url_menu = url_create.addon({'mode': 'category_add_item', 'type': 'artists', 'id': artist_id})
            ContextMenueItems.append(('Add artist to list', 'XBMC.RunPlugin('+url_menu+')'))
            
        if remove == True:                
            url_menu = url_create.addon({'mode': 'category_delete_item', 'type': type, 'filename': filename, 'id': artist_id})
            ContextMenueItems.append(('Remove artist from list', 'XBMC.RunPlugin('+url_menu+')'))
                        
        return ContextMenueItems

 
    def album_item(self, type, add=False, remove=False, artist_id='', album_id='', album_name='', icon='', user='', filename=''):
    
        ContextMenueItems = []
        
        url_create = Urlbuild(self.base_url)
        cm_add = ContextmenuAdd()
            
        if type == 'albums':
            url_menu = url_create.addon({'mode': 'play_album', 'album_id': album_id, 'album_name': album_name, 'album_image': icon})
            ContextMenueItems.append(('Play album', 'XBMC.RunPlugin('+url_menu+')'))
                
            if '' != artist_id:
                url_menu = url_create.addon({'mode': 'goto_artist', 'artist_id': artist_id})
                ContextMenueItems.append(('Go to artist', 'XBMC.Container.Refresh('+url_menu+')'))
                
                url_menu = url_create.addon({'mode': 'recommend_albums', 'seed': artist_id})
                ContextMenueItems.append(('Recommended albums', 'XBMC.Container.Refresh('+url_menu+')'))
            
            if add == True:                
                url_menu = url_create.addon({'mode': 'category_add_item', 'type': type, 'id': album_id})
                #ContextMenueItems.append(('Add album to list', 'XBMC.RunPlugin('+url_menu+')'))
            
            if '' != artist_id:
                url_menu = url_create.addon({'mode': 'category_add_item', 'type': 'artists', 'id': artist_id})
                ContextMenueItems.append(('Add artist to list', 'XBMC.RunPlugin('+url_menu+')'))
            
            if '' != album_id:
                url_menu = url_create.addon({'mode': 'category_add_item', 'type': 'albums', 'id': album_id})
                ContextMenueItems.append(('Add album to list', 'XBMC.RunPlugin('+url_menu+')'))
                
            if remove == True:                
                url_menu = url_create.addon({'mode': 'category_delete_item', 'type': type, 'filename': filename, 'id': album_id})
                ContextMenueItems.append(('Remove album from list', 'XBMC.RunPlugin('+url_menu+')'))
                
            cm_add.append(type, self.base_url, ContextMenueItems, album_id=album_id)
            
        elif type == 'playlist':
            url_menu = url_create.addon({'mode': 'play_playlist', 'playlist_id': album_id, 'user': user})
            ContextMenueItems.append(('Play playlist', 'XBMC.RunPlugin('+url_menu+')'))
            
            cm_add.append(type, self.base_url, ContextMenueItems, album_id=album_id, album_name=album_name, user=user)
                        
        return ContextMenueItems
    

 
    def track_item(self, add=False, remove=False, artist_id='', album_id='', track_id='', album_name='', icon='', user='', filename=''):
        type = 'tracks'
        ContextMenueItems = []
        
        url_create = Urlbuild(self.base_url)
        cm_add = ContextmenuAdd()

        url_menu = url_create.addon({'mode': 'queue_track', 'track_id': track_id})
        ContextMenueItems.append(('Queue track', 'XBMC.RunPlugin('+url_menu+')'))
        
        if '' != artist_id:
            url_menu = url_create.addon({'mode': 'goto_artist', 'artist_id': artist_id})
            ContextMenueItems.append(('Go to artist', 'XBMC.Container.Refresh('+url_menu+')'))
            
        if '' != album_id:
            url_menu = url_create.addon({'mode': 'goto_album', 'album_id': album_id})
            ContextMenueItems.append(('Go to album', 'XBMC.Container.Refresh('+url_menu+')'))
            
        if '' != artist_id:
            url_menu = url_create.addon({'mode': 'recommend_albums', 'seed': artist_id})
            ContextMenueItems.append(('Recommended albums', 'XBMC.Container.Refresh('+url_menu+')'))
            
        url_menu = url_create.addon({'mode': 'recommend_tracks', 'seed': track_id})
        ContextMenueItems.append(('Recommended tracks', 'XBMC.Container.Refresh('+url_menu+')'))
            
        if add == True:                
            url_menu = url_create.addon({'mode': 'category_add_item', 'type': type, 'id': track_id})
            #ContextMenueItems.append(('Add track to list', 'XBMC.RunPlugin('+url_menu+')'))
        
        if '' != artist_id:
            url_menu = url_create.addon({'mode': 'category_add_item', 'type': 'artists', 'id': artist_id})
            ContextMenueItems.append(('Add artist to list', 'XBMC.RunPlugin('+url_menu+')'))
        
        if '' != album_id:
            url_menu = url_create.addon({'mode': 'category_add_item', 'type': 'albums', 'id': album_id})
            ContextMenueItems.append(('Add album to list', 'XBMC.RunPlugin('+url_menu+')'))
        
        if '' != track_id:
            url_menu = url_create.addon({'mode': 'category_add_item', 'type': 'tracks', 'id': track_id})
            ContextMenueItems.append(('Add track to list', 'XBMC.RunPlugin('+url_menu+')'))
            
        if remove == True:                
            url_menu = url_create.addon({'mode': 'category_delete_item', 'type': type, 'filename': filename, 'id': track_id})
            ContextMenueItems.append(('Remove track from list', 'XBMC.RunPlugin('+url_menu+')'))
            
        cm_add.append(type, self.base_url, ContextMenueItems, id=track_id)
                        
        return ContextMenueItems
