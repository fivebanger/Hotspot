


class Helpers():
    
    def format_track_info(self, track=[]):
    
        artist_name = track['artists'][0]['name']
        artist_id = track['artists'][0]['id'] 
        album_name = track['album']['name']
        album_id = track['album']['id'] 
        track_name = track['name']
        track_id = track['id']
        track_no = track['track_number']
        duration = int(track['duration_ms'])/1000
        list_index = track['list_index']
        duration_ms = track['duration_ms']
        
        if len(track['album']['images']) >= 2:
            icon = track['album']['images'][1]['url']
        else:
            icon = 'DefaultAlbumCover.png'
        
        formated = {
                   'artist_name': artist_name,
                   'artist_id': artist_id,
                   'album_name': album_name, 
                   'album_id': album_id, 
                   'track_name': track_name,
                   'track_id': track_id,
                   'track_no': track_no,
                   'duration': duration,
                   'duration_ms': duration_ms,
                   'icon': icon,
                   'list_index': list_index
                  }
        
        return formated