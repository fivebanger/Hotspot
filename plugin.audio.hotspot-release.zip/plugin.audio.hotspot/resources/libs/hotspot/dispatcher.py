
import xbmc
import xbmcgui
import dirs
from os.path import expanduser
from hotspot import Hotspot
from token_handler import TokenHandler
from dispatcher_add import DispatcherAdd
from appkey_handler import AppkeyHandler


log_level = xbmc.LOGDEBUG


class Dispatcher():
    
    def __init__(self, base_url, addon_handle, addon_args):
        self.base_url = base_url
        self.addon_handle = addon_handle
        self.addon_args = addon_args
            
    def route(self):
        addon_args = self.addon_args
        
        if False == bool(addon_args):
            mode = 'main_menu'
        else:
            mode = addon_args['mode']
            
        xbmc.log('Hotspot: Dispatcher  mode: %s, addon_args: %s' %(mode, addon_args), xbmc.LOGDEBUG)
        
        if mode == 'clear_cache':
            dialog = xbmcgui.Dialog()
            retval = dialog.yesno('Clear cache', 'Clear cache and remove all user data?')
            if True == retval: 
                dirs.clear_cache()
            return
        
        if mode == 'export_token':
            dialog = xbmcgui.Dialog()
            path = expanduser("~")
            #folder = dialog.browse(0,"Token directory","files", '.jsn', False, False, path)
            folder = dialog.browse(0,"Token export directory","files")
            if '' != folder:
                retval = dialog.yesno('Export token', 'Export token to %s ?' %folder)
                if True == retval: 
                    th = TokenHandler()
                    th.export_token(folder)
            return
        
        if mode == 'import_token':
            dialog = xbmcgui.Dialog()
            path = expanduser("~")
            #folder = dialog.browse(1,"Token directory","files", '.jsn', False, False, path)
            folder = dialog.browse(1,"Select token file" ,"files", ".jsn")
            if 'jsn' in folder:
                th = TokenHandler()
                th.import_token(folder)
            return
        
        if mode == 'export_appkey':
            ah = AppkeyHandler()
            ah.expport_appkey()
            return
        
        if mode == 'import_appkey':
            ah = AppkeyHandler()
            ah.import_appkey()
            return
            
        htspt   = Hotspot(self.base_url, self.addon_handle)
        dsp_add = DispatcherAdd(self.base_url, self.addon_handle, self.addon_args)
        
        if mode == 'main_menu':
            htspt.main_menu()
        
        elif mode == 'search_artists':
            htspt.search_artists()
            
        elif mode == 'search_artists_next':
            search_str = addon_args['search_str']
            offset = addon_args['offset']
            list_index = addon_args['list_index']
            htspt.search_artists(search_str, offset, list_index)
        
        elif mode == 'search_albums':
            htspt.search_albums()
            
        elif mode == 'search_albums_next':
            search_str = addon_args['search_str']
            offset = addon_args['offset']
            list_index = addon_args['list_index']
            htspt.search_albums(search_str, offset, list_index)
        
        elif mode == 'search_tracks':
            htspt.search_tracks()
            
        elif mode == 'search_tracks_next':
            search_str = addon_args['search_str']
            offset = addon_args['offset']
            list_index = addon_args['list_index']
            htspt.search_tracks(search_str, offset, list_index)
        
        elif mode == 'my_playlists':
            offset=addon_args['offset']
            list_index=addon_args['list_index']
            htspt.my_playlists(offset, list_index)
        
        elif mode == 'my_playlists_tracks': 
            pos = addon_args['pos']
            user = addon_args['user']
            htspt.my_playlists_tracks(pos, user)
        
        elif mode == 'goto_artist':
            artist_id = addon_args['artist_id']
            htspt.goto_artist(artist_id)
        
        elif mode == 'goto_album':
            album_id = addon_args['album_id']
            htspt.goto_album(album_id)
        
        elif mode == 'show_artist_albums':
            artist_id = addon_args['artist_id']
            htspt.show_artist_albums(artist_id)
            
        elif mode == 'show_album_tracks':
            album_id = addon_args['album_id']
            album_image = addon_args['album_image']
            album_name = addon_args['album_name']
            htspt.show_album_tracks(album_id, album_image, album_name)
         
        elif mode == 'show_related_artists':
            id=addon_args['artist_id']
            htspt.show_related_artists(id)
        
        elif mode == 'show_artist_singles':
            id=addon_args['artist_id']
            htspt.show_artist_singles(id)
        
        elif mode == 'show_artist_appears_on':
            id=addon_args['artist_id']
            htspt.show_artist_appears_on(id)
                
        elif mode == 'show_artist_compilations':
            id=addon_args['artist_id']
            htspt.show_artist_compilations(id)

        elif mode == 'show_album_next':
            artist_id=addon_args['search_str']
            offset=addon_args['offset']
            list_index=addon_args['list_index']
            xbmc.log('Hotspot: list_index: %s' %list_index, xbmc.LOGERROR)
            htspt.show_artist_albums(artist_id, offset, list_index)
            
        elif mode == 'show_single_next':
            artist_id=addon_args['search_str']
            offset=addon_args['offset']
            list_index=addon_args['list_index']
            htspt.show_artist_singles(artist_id, offset, list_index)
            
        elif mode == 'show_appears_on_next':
            artist_id=addon_args['search_str']
            offset=addon_args['offset']
            list_index=addon_args['list_index']
            htspt.show_artist_appears_on(artist_id, offset, list_index)
            
        elif mode == 'show_compilation_next':
            artist_id=addon_args['search_str']
            offset=addon_args['offset']
            list_index=addon_args['list_index']
            htspt.show_artist_compilations(artist_id, offset, list_index)
            
        elif mode == 'show_artists_toptracks':
            id=addon_args['artist_id']
            htspt.show_artists_toptracks(id)
            
        elif mode == 'queue_track':
            id=addon_args['track_id']
            htspt.queue_track(id)
            
        elif mode == 'play_album':
            album_id=addon_args['album_id']
            album_image = addon_args['album_image']
            album_name = addon_args['album_name']
            htspt.play_album(album_id, album_image, album_name)
            
        elif mode == 'play_playlist':
            id=addon_args['playlist_id']
            user = addon_args['user']
            htspt.play_playlist(id, user)
            
        elif mode == 'update_fanart':
            type=addon_args['type']
            filename =addon_args['filename']
            htspt.update_fanart(type, filename)
            
        elif mode == 'spotify_menu':
            htspt.spotify_menu()
            
        elif mode == 'current_user_saved_albums':
            offset=addon_args['offset']
            list_index=addon_args['list_index']
            htspt.current_user_saved_albums(offset, list_index)
            
        elif mode == 'import_saved_album':
            filename =addon_args['filename']
            htspt.current_user_saved_albums_import(filename)
            
        elif mode == 'current_user_saved_tracks':
            offset=addon_args['offset']
            list_index=addon_args['list_index']
            htspt.current_user_saved_tracks(offset, list_index)
            
        elif mode == 'genres':
            htspt.genres()
            
        elif mode == 'show_genre_items':
            genre_id=addon_args['genre_id']
            htspt.genre_items(genre_id)
            
        elif mode == 'new_releases':
            htspt.new_releases()
            
        elif mode == 'current_user_top_artists':
            htspt.current_user_top_artists()
            
        elif mode == 'current_user_top_tracks':
            htspt.current_user_top_tracks()
            
        elif mode == 'recommend_albums':
            seed = addon_args['seed']
            htspt.recommend_albums(seed)
            
        elif mode == 'recommend_tracks':
            seed = addon_args['seed']
            htspt.recommend_tracks(seed)
            
        elif mode == 'recommend_genre':
            seed = addon_args['seed']
            htspt.recommend_genre(seed)
            
        elif mode == 'categories':
            filename = addon_args['filename']
            htspt.categories(filename)
            
        elif mode == 'category_add':
            htspt.category_add()
            
        elif mode == 'category_rename':
            name = addon_args['name']
            htspt.category_rename(name)
            
        elif mode == 'category_move':
            name = addon_args['name']
            htspt.category_move(name)
            
        elif mode == 'category_delete':
            name = addon_args['name']
            htspt.category_delete(name)
            
        elif mode == 'category_add_item':
            type = addon_args['type']
            id = addon_args['id']
            htspt.category_add_item(type, id)
            
        elif mode == 'category_delete_item':
            id = addon_args['id']
            type = addon_args['type']
            filename = addon_args['filename']
            name = 'list'
            htspt.remove_from_list(id, type, filename, name)
            
        elif mode == 'get_artists_from_fanart':
            htspt.get_artists_from_fanart()
            
        elif mode == 'recently_menu':
            htspt.recently_menu()
            
        elif mode == 'recently_items':
            type = addon_args['type']
            htspt.recently_items(type)
            htspt.recently_menu()
            
        elif mode == 'recently_items_play':
            type = addon_args['type']
            htspt.recently_items(type, True)
            
        elif mode == 'on_play_song':
            track_id = addon_args['track_id']
            htspt.on_play_song(track_id)
            
        elif False == dsp_add.route():
            xbmc.log('Hotspot: Dispatcher route: wrong mode: %s' %mode, xbmc.LOGERROR)
            
        else:
            pass
            
        return
        