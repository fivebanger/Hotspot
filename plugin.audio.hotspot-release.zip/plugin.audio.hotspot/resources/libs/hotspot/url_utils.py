
import urllib
import urllib2

class Urlbuild():
    
    def __init__(self, base_url):
        self.base_url = base_url
        
    def addon(self, query):
        return self.base_url + '?' + urllib.urlencode(query)
    
    def proxy_track(self, server_port, track_id, index='1', duration=0, use_header=False ):
        
        #http://127.0.0.1:8081/track/3n14UOwEsWw7W8iYj1mx1v.wav|X-Spotify-Token=2ebd7f9bfe51bad4c305dd938ab9b420e3ecd65e&User-Agent=Spotlight+1.0
        #http://127.0.0.1:8081/track/3n14UOwEsWw7W8iYj1mx1v.wav|X-Spotify-Token=2ebd7f9bfe51bad4c305dd938ab9b420e3ecd65e&User-Agent=Spotlight+1.0
        #http://127.0.0.1:8081/track/3n14UOwEsWw7W8iYj1mx1v.wav|X-Spotify-Token=b948391186c25ad9c83e5647605b7969a517b9c4&User-Agent=Spotlight+1.0
        host = '127.0.0.1'
        port = server_port
        #track_id = '3n14UOwEsWw7W8iYj1mx1v'
        token = 'd575a6ab9a4a77a85fe26cd35ef95018d2859b42'
        agent = 'Hotspot'
        
        response = urllib2.urlopen('http://127.0.0.1:'+server_port+'/token?agent=Hotspot')
        token = response.read()
    
        '''
        #return 'http://'+host+':'+port+'/track/'+track_id+'.wav|X-Spotify-Token='+token+'&User-Agent=Spotlight+1.0'
        #return 'http://'+host+':'+port+'/track/'+track_id+'|X-Spotify-Token='+token+'&User-Agent=Spotlight+1.0'
        #http://127.0.0.1:8081/track?index=1&track_id=3n14UOwEsWw7W8iYj1mx1v.wav
        url = 'http://'+host+':'+port+'/track?index='+str(index)+'&track_id='+track_id+'|X-Spotify-Token='+token+'&User-Agent=Spotlight+1.0'
        #return 'http://'+host+':'+port+'/track/'+track_id+'.wav|X-Spotify-Token='+token+'&'+agent
        #print url
        return url
        '''
        # add track number since Yatse uses link as sort method. 
        # Use first 4 digits of track id since Kodi 14.x cannot handle track?index=NN&track_id=NNNNNN urls
        if index > 9999:
            index = 9999
        index = str(index)
        index = index.zfill(4)
        
        if duration > 9999999:
            duration = 9999999
        duration = str(duration)
        duration = duration.zfill(7)
        
        #hmk track_id = index+duration+track_id
        track_id = index+'_'+duration+'_'+track_id  #hmk
        #url =  'http://'+host+':'+port+'/track/'+track_id+'.wav|X-Spotify-Token='+token+'&User-Agent=Hotspot'
        #url =  'http://'+host+':'+port+'/track/?index='+str(index)+'&track_id='+track_id+'.wav|X-Spotify-Token='+token+'&User-Agent=Hotspot'
        if False == use_header:
            url =  'http://'+host+':'+port+'/track/'+track_id+'.wav'
        else:
            url =  'http://'+host+':'+port+'/track/'+track_id+'.wav|X-Spotify-Token='+token+'&User-Agent='+agent
    
        #return 'http://'+host+':'+port+'/track/'+track_id+'.wav|X-Spotify-Token='+token+'&'+agent
        #print url
        return url
    
    
    
    def proxy_image(self, server_port, image_id=''):
    
        token = '1234';
        agent = 'Hotspot';
        host  = '127.0.0.1';
        port  = server_port;
            
        #print token
        #print agent
        #print host
        #print port
        #print image_id
        
        #http://127.0.0.1:8081/track/3n14UOwEsWw7W8iYj1mx1v.wav|X-Spotify-Token=2ebd7f9bfe51bad4c305dd938ab9b420e3ecd65e&User-Agent=Spotlight+1.0
        #http://127.0.0.1:8081/track/3n14UOwEsWw7W8iYj1mx1v.wav|X-Spotify-Token=2ebd7f9bfe51bad4c305dd938ab9b420e3ecd65e&User-Agent=Spotlight+1.0
        #http://127.0.0.1:8081/track/3n14UOwEsWw7W8iYj1mx1v.wav|X-Spotify-Token=b948391186c25ad9c83e5647605b7969a517b9c4&User-Agent=Spotlight+1.0
        #host = '127.0.0.1'
        #port = '8081'
        #track_id = '3n14UOwEsWw7W8iYj1mx1v'
        token = 'd575a6ab9a4a77a85fe26cd35ef95018d2859b42'
        agent = 'Hotspot'
        
        #return 'http://'+host+':'+port+'/track/'+track_id+'.wav|X-Spotify-Token='+token+'&User-Agent=Spotlight+1.0'
        #return 'http://'+host+':'+port+'/track/'+track_id+'|X-Spotify-Token='+token+'&User-Agent=Spotlight+1.0'
        #http://127.0.0.1:8081/track?index=1&track_id=3n14UOwEsWw7W8iYj1mx1v.wav
        url = 'http://'+host+':'+port+'/image/'+image_id+'.jpg|X-Spotify-Token='+token+'&User-Agent='+agent
        #return 'http://'+host+':'+port+'/track/'+track_id+'.wav|X-Spotify-Token='+token+'&'+agent
        #print url
        return url