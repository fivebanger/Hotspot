import os.path
import urllib
import urllib2
import xml.etree.ElementTree as ET
import json
import time
import xbmcgui
import xbmc
import dirs
from data import HtsptData
from playlists import Playlist


log_level = xbmc.LOGDEBUG


class Fanart():
    
    def __init__(self):
        self.artsi_ids_seen = []
        self.dialog = xbmcgui.DialogProgress()
        self.api_key_adb = '41214789306c4690752dfb'
        self.api_key_ftv = 'ed4b784f97227358b31ca4dd966a04f1'
        self._search_ftv = True
        self.write = False 
        self.artist_urls = self._load_fanart_list('artist_urls')
        self.mbrain_ids = self._load_fanart_list('mbrainz_ids')

                
    def _load_fanart_list(self, type):
        data = HtsptData()
        results_fanart = data.load_list('fanart', 'fanart')
        if 'artist_urls' == type:
            try:
                result = results_fanart['artist_urls']
            except:
                result = {}
        elif 'mbrainz_ids' == type:
            try:
                result = results_fanart['mbrainz_ids']
            except:
                result = {}
        else:
            result = ''
        return result

                
    def _save_fanart_list(self, type, list):
        data = HtsptData()
        results_fanart = data.load_list('fanart', 'fanart')
        artist_urls = self._load_fanart_list('artist_urls')
        mbrain_ids = self._load_fanart_list('mbrainz_ids')
        
        if 'artist_urls' == type:
            fanart = {'artist_urls': list, 'mbrainz_ids': mbrain_ids}
        elif 'mbrainz_ids' == type:
            fanart = {'artist_urls': artist_urls, 'mbrainz_ids': list}
        else:
            xbmc.log( ('Hotspot: Artwork error, no type defined: %s' % type), xbmc.LOGERROR)
            return

        data.save_list(type, 'fanart', fanart, results_fanart)
    
    
    def _get_mbrainz_id(self, artist_name):
        #http://musicbrainz.org/ws/2/artist/?query=artist:Scorpions
        query = urllib.urlencode({'query': 'artist:'+artist_name.encode('utf-8')})
        musicbrainz_url = 'http://musicbrainz.org/ws/2/artist/?' + query
        retry = 10
        mb_ids = []
        xml_response = ''
        while retry:            
            try:
                # create a request object
                req = urllib2.Request(musicbrainz_url)
                # and open it to return a handle on the url
                response = urllib2.urlopen(musicbrainz_url)
                xml_response = response.read()
                retry = 0
            except urllib2.HTTPError, e:          
                if e.code == 503:
                    #print 'Musicbrainz retry ' + str(retry)
                    if 0 == retry:
                        return ''
                    time.sleep(1)
                    retry -= 1            
                elif e.code == 404:
                    pass
                else:
                    pass

        try:
            root = ET.fromstring(xml_response)
            for artist_list in root:
                for artist in artist_list:
                    mb_ids.append(artist.attrib['id'])
        except:
            xbmc.log( ('Artist ' + artist_name.encode('utf-8') + ' not in Musicbrainz data base'), log_level )
            pass
        
        if 0 == len(mb_ids):
            mb_ids.append('')

        return mb_ids
    
    
    def _get_img_url_ftv(self, mb_id, artist_name=''):
        
        background_url = None
        
        if '' == mb_id:
            return background_url
        
        #http://webservice.fanart.tv/v3/music/c3cceeed-3332-4cf0-8c4c-bbde425147b6?api_key=ed4b784f97227358b31ca4dd966a04f1
        fanart_url = 'http://webservice.fanart.tv/v3/music/%s?api_key=%s' %(mb_id, self.api_key_ftv)
        retry = 10
        while retry:             
            try:
                # create a request object
                req = urllib2.Request(fanart_url)
                # and open it to return a handle on the url
                response = urllib2.urlopen(fanart_url)
                json_response = response.read()
                retry = 0
            except urllib2.HTTPError, e:              
                if e.code == 503:
                    xbmc.log( 'Fanart retry', log_level )
                    if 0 == retry:
                        return ''
                    time.sleep(1)
                    retry -= 1            
                if e.code == 404:
                    xbmc.log( ('Not found in fanart.tv: ' + artist_name.encode('utf-8')), log_level )
                    return ''
                else:
                    return ''

            try:       
                result = json.loads( json_response )
                background_url = result['artistbackground'][0]['url']
            except:
                xbmc.log(  ('Artist ' + artist_name.encode('utf-8') + ' not in Fantarts data base'), log_level )
        
        return background_url
                    
                        
    def _get_data_adb(self, artist):
        
        result = {'artists': None}
        
        if '' == artist:
            return result
        
        #http://www.theaudiodb.com/api/v1/json/{api_key}/search.php?s={artist_name}
        #http://www.theaudiodb.com/api/v1/json/41214789306c4690752dfb/search.php?s=nighthawks
        fanart_url = 'http://www.theaudiodb.com/api/v1/json/%s/search.php?s=%s' %(self.api_key_adb, artist)
        fanart_url = 'http://www.theaudiodb.com/api/v1/json/%s/search.php?' %(self.api_key_adb)
        query = {'s': artist.encode('utf-8')}
        fanart_url = fanart_url + urllib.urlencode(query)
        
        retry = 10
        while retry:             
            try:
                # create a request object
                req = urllib2.Request(fanart_url)
                # and open it to return a handle on the url
                response = urllib2.urlopen(fanart_url)
                json_response = response.read()
                retry = 0
            except urllib2.HTTPError, e:              
                if e.code == 503:
                    xbmc.log( 'Fanart retry', log_level )
                    if 0 == retry:
                        return result
                    time.sleep(1)
                    retry -= 1            
                if e.code == 404:
                    xbmc.log( ('Not found in theaudiodb.com: ' + artist_name.encode('utf-8')), log_level )
                    return result
                else:
                    return result

            try:       
                result = json.loads( json_response )
            except:
                xbmc.log(  ('Artist ' + artist_name.encode('utf-8') + ' not in Fantarts data base'), log_level )
        
        return result
    
    
    def _get_img_url_adb(self, artist):
        fanart = None
        result = self._get_data_adb(artist)
        if None != result['artists']:
            fanart = result['artists'][0]['strArtistFanart']

        return fanart
    
    
    def _get_img_url(self, artist_name, artist_id='0000'):
        #check theaudiodb.com        
        url = self._get_img_url_adb(artist_name)
        
        if None == url and True == self._search_ftv:
            #check fanart.tv
            mb_ids = []
            
            if artist_id in self.mbrain_ids:
                mb_ids.append(self.mbrain_ids[artist_id])
            else:
                if artist_id in self.artsi_ids_seen:
                    mb_ids.append('')
                else:
                    mb_ids = self._get_mbrainz_id(artist_name)
                    if '' != mb_ids[0]:
                        self.write = True
                        mbrain_id = {artist_id: mb_ids[0]}
                        self.mbrain_ids.update(mbrain_id)
                        
            if (not artist_id in self.artist_urls) and (not artist_id in self.artsi_ids_seen) and ('' != mb_ids[0]):
            #if (not artist_id in artist_urls) and (not artist_id in self.mb_ids[0]):
                '''
                due to score system of musicbrainz we have to inspect the first two or three elements of the result
                and cannot rely any longer that the first element is the artist we are looking for
                '''
                for mb_id in mb_ids[0:2]:
                    url = self._get_img_url_ftv(mb_id, artist_name)
                    if None != url:
                        break
                 
        if None != url:
            self.write = True
            artist_url = {artist_id: url}
            self.artist_urls.update(artist_url)
               
        return url
                    
                        
    def _update_fanart(self, artists, dialog_info):
        pos = 1

        for artist in artists:
                               
            artist_name = artist['name']
            artist_id = artist['id']
            
            progress = ( (pos * 100) / len(artists) )
            self.dialog.update(progress, dialog_info, artist_name)
            
            if (not artist_id in self.artist_urls) and (not artist_id in self.artsi_ids_seen):
                self._get_img_url(artist_name, artist_id)

            pos += 1
            self.artsi_ids_seen.append(artist_id)
            if self.dialog.iscanceled()==True:
                break
                    
                        
    def _update_artists(self, artists, dialog_info):
        self._update_fanart(artists, dialog_info)
        self._finalize()
    
    
    def _update_albums(self, albums, dialog_info=''):
        pos = 1
        
        for album in albums:
            artists = []
            tracks = album['tracks']['items']
            
            dialog_info = 'Update album ' + str(pos) + '/' + str(len(albums))
    
            if len(tracks) > 0:
                for track in tracks:
                    artist_name = track['artists'][0]['name']
                    artist_id = track['artists'][0]['id']
                    
                    item = {'name': artist_name, 'id': artist_id}
                    
                    artists.append(item)            
            
            pos += 1
            self._update_fanart(artists, dialog_info)
            if self.dialog.iscanceled()==True:
                break

        self._finalize()

                        
                        
    def _update_playlists(self, playlists, dialog_info=''):
        pos = 1
        pl = Playlist()
        
        for playlist in playlists:
            artists = []
            
            dialog_info = 'Update playlist ' + str(pos) + '/' + str(len(playlists))
            
            if playlist.get('owner'):
                #web api
                user = playlist['owner']['id']
                id = playlist['id']
                
                playlist_tracks = pl.load_tracks(id, user)
                tracks = playlist_tracks['items']
        
                if len(tracks) > 0:
                    for track in tracks:
                        artist_name = track['track']['artists'][0]['name']
                        artist_id = track['track']['artists'][0]['id']
                        
                        item = {'name': artist_name, 'id': artist_id}
                        artists.append(item)
            else:
                #proxy server
                user = 'void'
                pos_tmp = pos - 1
                
                playlist_tracks = pl.load_tracks(pos_tmp, user)
                tracks = playlist_tracks['items']
        
                if len(tracks) > 0:
                    for track in tracks:
                        artist_name = track['artists'][0]['name']
                        artist_id = track['artists'][0]['id']
                        
                        item = {'name': artist_name, 'id': artist_id}
                        artists.append(item)
                        
            pos += 1
            self._update_fanart(artists, dialog_info)
            if self.dialog.iscanceled()==True:
                break

        self._finalize()

                        
    def _update_tracks(self, tracks, dialog_info=''):
        
        artists = []
        
        for track in tracks:
            artist_name = track['artists'][0]['name']
            artist_id = track['artists'][0]['id']
            
            item = {'name': artist_name, 'id': artist_id}
            artists.append(item)

        self._update_fanart(artists, dialog_info)
        self._finalize()
    
    
    def _finalize(self):
        if self.write:
            self._save_fanart_list('artist_urls', self.artist_urls)
            self._save_fanart_list('mbrainz_ids', self.mbrain_ids)
    
    
    def add_artist(self, artist):
        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create('Update fanart')
        dialog_info = 'Update artists'
        self._update_artists([artist], dialog_info)
        self.dialog.close()
    
    
    def add_album(self, album):
        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create('Update fanart')
        dialog_info = 'Update albums'
        tracks = album['tracks']['items']
        self._update_tracks(tracks, dialog_info)
        self.dialog.close()
    
    
    def add_track(self, tracks):
        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create('Update fanart')
        dialog_info = 'Update tracks'
        self._update_tracks(tracks, dialog_info)
        self.dialog.close()
    
    
    def add_item(self, item, type):
        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create('Update fanart')
        
        if type == 'artists':
            dialog_info = 'Update artists'
            is_canceled = self._update_artists([item], dialog_info)
        elif type == 'albums':
            dialog_info = 'Update albums'
            tracks = item['tracks']['items']
            is_canceled = self._update_tracks(tracks, dialog_info)
        elif type == 'tracks':
            dialog_info = 'Update tracks'
            is_canceled = self._update_tracks([item], dialog_info)
        else:
            xbmc.log('wrong type', log_level)
            
        self.dialog.close()
        


    def update_database(self, type, filename):
        data = HtsptData()
        path = dirs.check_addon_data_path('artwork')
        
        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create('Update fanart')
        
        if 'artists' == type:
            results = data.load_list(type, filename)
            artists = results['artists']
            if len(artists) > 0:
                dialog_info = 'Update artists'
                self._update_artists(artists, dialog_info)

        elif 'albums' == type:
            results = data.load_list(type, filename)
            albums = results['albums']
            pos = 0
            if len(albums) > 0:
                dialog_info = 'Update albums'
                self._update_albums(albums, dialog_info)

        elif 'tracks' == type:
            results = data.load_list(type, filename)
            tracks = results['tracks']         
            if len(tracks) > 0:
                dialog_info = 'Update tracks'
                self._update_tracks(tracks, dialog_info)

        elif 'playlists' == type:
            pl = Playlist()
            playlists = pl.load_playlists()
            playlists = playlists['items']
            if len(playlists) > 0:
                dialog_info = 'Update playlists'
                self._update_playlists(playlists, dialog_info)

        self.dialog.close()


    def download_image(self, artist_name, path, artist_id='test'):
        image_file = os.path.join(path, artist_id+'.jpg')
        if not os.path.exists(image_file):
            background_url = self._get_img_url(artist_name, artist_id)
            if '' != background_url:
                retry = 10
                while retry:             
                    try:
                        # create a request object
                        req = urllib2.Request(background_url)
                        # and open it to return a handle on the url
                        response = urllib2.urlopen(background_url)
                        image = response.read()
    
                        fd = open(image_file, 'wb')
                        fd.write(image)
                        fd.close()
                        
                        retry = 0
                    except urllib2.HTTPError, e:              
                        if e.code == 503:
                            xbmc.log( 'Fanart retry', log_level )
                            time.sleep(1)
                            retry -= 1            
                        if e.code == 404:
                            xbmc.log( ('Not found in fanart.tv: ' + artist_name.encode('utf-8')), log_level )
                            retry = 0
                        else:
                            retry = 0

