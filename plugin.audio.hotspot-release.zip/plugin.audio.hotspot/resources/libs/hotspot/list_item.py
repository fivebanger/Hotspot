import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmc
import os
from context_menu import Contextmenu
from context_menu_add import ContextmenuAdd
from url_utils import Urlbuild

class ListItem():
    
    def __init__(self, addon_handle, base_url=''):
        self.addon_handle = addon_handle
        addon_id = 'plugin.audio.hotspot'
        self.addon = xbmcaddon.Addon(addon_id)
        self.base_url = base_url
        self.cm = Contextmenu(base_url)
        self.cm_items = []
        self.path = ''
        self.replace_items = True


    def addon_path(self, path):
        url_build = Urlbuild(self.base_url)
        self.path = url_build.addon(path)


    def proxy_path(self, server_port, track_id, list_index, duration_ms):
        url_build = Urlbuild(self.base_url)
        self.path = url_build.proxy_track(server_port, track_id, list_index, duration_ms)


    def menu(self, type, name, icon='', fanart=''):
        # content: files, songs, artists, albums, movies, tvshows, episodes, musicvideos
        content = 'files'
        
        if '' == fanart:
            fanart = os.path.join(self.addon.getAddonInfo('path'),'fanart.jpg')
            
        if '' == icon:
            icon = 'DefaultFolder.png'
        
        if type == 'main_menu':
            list_name = name
        elif type == 'spotify_menu':
            list_name = name
        elif type == 'recently_menu':
            list_name = name
        elif type == 'genre':
            list_name = name
        else:
            return None
        
        li = xbmcgui.ListItem(list_name, iconImage=icon)
        li.setArt( icon )
        li.setProperty('fanart_image', fanart)
        li.addContextMenuItems(self.cm_items, replaceItems=self.replace_items)
        
        xbmcplugin.addDirectoryItem(self.addon_handle, self.path, li, isFolder=True)
        xbmcplugin.setContent(self.addon_handle, content)


    def artist(self, artist, list_index, icon, len, fanart=''):
        # content: files, songs, artists, albums, movies, tvshows, episodes, musicvideos
        content = 'files'
        
        if '' == fanart:
            fanart = os.path.join(self.addon.getAddonInfo('path'),'fanart.jpg')

        #list_name = str(list_index) + '. ' + artist
        list_name = artist
        
        li = xbmcgui.ListItem(list_name, iconImage=icon)
        li.setArt( icon )
        li.setProperty('fanart_image', fanart)
        li.addContextMenuItems(self.cm_items, replaceItems=self.replace_items)
        
        xbmcplugin.addDirectoryItem(self.addon_handle, self.path, li, isFolder=True, totalItems=len)
        xbmcplugin.setContent(self.addon_handle, content)
        

    def album(self, artist, album, list_index, icon, len, fanart=''):
        # content: files, songs, artists, albums, movies, tvshows, episodes, musicvideos
        content = 'files'

        if '' == fanart:
            fanart = os.path.join(self.addon.getAddonInfo('path'),'fanart.jpg')
        
        if '' != artist:            
            list_name = album + ' - ' + artist
        else:
            list_name = album
        #list_name = album
        
        li = xbmcgui.ListItem(list_name, iconImage=icon)
        li.setArt( icon )
        li.setProperty('fanart_image', fanart)
        li.addContextMenuItems(self.cm_items, replaceItems=self.replace_items)
        
        xbmcplugin.addDirectoryItem(self.addon_handle, self.path, li, isFolder=True, totalItems=len)
        xbmcplugin.setContent(self.addon_handle, content)


    def track(self, artist, album, track, list_index, track_no, duration, icon, play, len, fanart=''):
        # content: files, songs, artists, albums, movies, tvshows, episodes, musicvideos
        content = 'songs'
        info_type = 'music'
        infoLabels = {}
        
        if '' == fanart:
            fanart = os.path.join(self.addon.getAddonInfo('path'),'fanart.jpg')
        
        index = str(list_index)
        index = index.zfill(2)
        if artist == '':
            list_name = index + '. ' + track
        else:
            list_name = index + '. ' + track + ' - ' + artist
        '''
        - tracknumber : integer (8)
        - discnumber : integer (2)
        - duration : integer (245) - duration in seconds
        - year : integer (1998)
        - genre : string (Rock)
        - album : string (Pulse)
        - artist : string (Muse)
        - title : string (American Pie)
        - rating : string (3) - single character between 0 and 5
        - lyrics : string (On a dark desert highway...)
        - playcount : integer (2) - number of times this item has been played
        - lastplayed : string (Y-m-d h:m:s = 2009-04-05 23:16:04)
        '''
        infoLabels = {'tracknumber': list_index, 'duration': duration, 'album': album, 'artist': artist, 'title': track}
        
        li = xbmcgui.ListItem(list_name, iconImage=icon)
        li.setInfo(info_type, infoLabels)
        '''
        - thumb : string - image filename
        - poster : string - image filename
        - banner : string - image filename
        - fanart : string - image filename
        - clearart : string - image filename
        - clearlogo : string - image filename
        - landscape : string - image filename
        - icon : string - image filename
        '''
        li.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})
        #li.setProperty('fanart_image', fanart)
        
        li.addContextMenuItems(self.cm_items, replaceItems=self.replace_items)
        
        if False == play:
            xbmcplugin.addDirectoryItem(self.addon_handle, self.path, li, isFolder=False, totalItems=len)
            xbmcplugin.setContent(self.addon_handle, content)
        else:
            pl = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)      
            pl.add(self.path, listitem=li)
        

    def next(self, icon=''):
        
        content = 'files'
        fanart = os.path.join(self.addon.getAddonInfo('path'),'fanart.jpg')
        list_name = 'Next'
        
        if '' == icon:
            icon = 'DefaultFolder.png'
        
        li = xbmcgui.ListItem(list_name, iconImage=icon)
        li.setArt( icon )
        li.setProperty('fanart_image', fanart)

        xbmcplugin.addDirectoryItem(self.addon_handle, self.path, li, isFolder=True)
        xbmcplugin.setContent(self.addon_handle, content)
        
        
    def end_of_directory(self):
        xbmcplugin.endOfDirectory(self.addon_handle)


    def cm_none(self):
        self.cm_items = []


    def cm_menu(self, type, name='', media='', id='', filename=''):
        self.cm_items = self.cm.menu_item(type, name, media, id, filename)

 
    def cm_artist(self, add=False, remove=False, artist_id='', filename=''):
        self.cm_items = self.cm.artist_item(add, remove, artist_id, filename)

 
    def cm_album(self, type, add=False, remove=False, artist_id='', album_id='', album_name='', icon='', user='', filename=''):
        self.cm_items = self.cm.album_item(type, add, remove, artist_id, album_id, album_name, icon, user, filename)
    

 
    def cm_track(self, add=False, remove=False, artist_id='', album_id='', track_id='', album_name='', icon='', user='', filename=''):
        self.cm_items = self.cm.track_item(add, remove, artist_id, album_id, track_id, album_name, icon, user, filename)
        
        