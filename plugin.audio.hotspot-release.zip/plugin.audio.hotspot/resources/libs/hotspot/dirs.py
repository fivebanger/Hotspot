
import os
import shutil
import xbmcaddon
import xbmcvfs
import xbmc

log_level = xbmc.LOGDEBUG
    
    
def get_addon_path():     
    addon_id = 'plugin.audio.hotspot'
    addon = xbmcaddon.Addon(addon_id)
    addon_path = addon.getAddonInfo('path')

    return addon_path

              
def check_addon_data_path(dir=None):     
    addon_id = 'plugin.audio.hotspot'
    data_dir = xbmc.translatePath('special://profile/addon_data/'+addon_id)
    if None == dir:
        addon_data_dir = data_dir
    else:
        addon_data_dir = os.path.join(data_dir, dir)
    
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)

    return addon_data_dir
    
    
def get_addon_data_path():     
    addon_id = 'plugin.audio.hotspot'
    data_dir = xbmc.translatePath('special://profile/addon_data/'+addon_id)

    return addon_data_dir
          
def check_htspt_data_path(dir='.htsptdat'):
    addon_id = 'plugin.audio.hotspot'
    addon = xbmcaddon.Addon(addon_id)
    xchange_folder = addon.getSetting('xchange_folder')
    if '' != xchange_folder:
        xchange_folder = file=os.path.join(xchange_folder, dir)
    
        if not xbmcvfs.exists(xchange_folder):  #xbmcvfs.exists needs '/' at end
            xbmc.log('Create hotspot data folder', log_level)
            xbmcvfs.mkdir(xchange_folder)
    else:
        xchange_folder = check_addon_data_path(dir)

    return xchange_folder

          
def get_htspt_data_path():
    addon_id = 'plugin.audio.hotspot'
    addon = xbmcaddon.Addon(addon_id)
    xchange_folder = addon.getSetting('xchange_folder')
    if '' == xchange_folder:
        xchange_folder = get_addon_data_path()

    return xchange_folder
    
          
def get_proxy_path():
    addon_id = 'plugin.audio.hotspot'
    addon = xbmcaddon.Addon(addon_id)
    server_host = 'http://127.0.0.1'
    server_port = addon.getSetting('internal_server_port')

    return server_host+':'+server_port
    
          
def clear_cache():
    data_dir = get_addon_data_path()
    dir = os.path.join(data_dir, 'libspotify')

    if os.path.exists(dir):
        shutil.rmtree(dir)
        
    return
    
          
def check_dir(dir):
    if not xbmcvfs.exists(dir):
        xbmcvfs.mkdir(dir)

    return dir

