import os
import json
import xbmcaddon
import xbmcvfs
import xbmc
import xbmcgui
import dirs


class AppkeyHandler(object):
    
    def __init__(self):
        return
    
    
    def _h2arr(self, file):
        result = []
        
        try:
            fh = xbmcvfs.File(file, 'r')
            data = fh.read()
            fh.close()
            
            data = data.replace('\n', '')
            data = data.replace('\r', '')
            data = data.replace('\t', '')
            data = data.replace(' ', '')
            data = data.replace('{', ',')
            data = data.split(',')
            
            for item in data:
                if '0x' in item:
                    result.append(int(item, 16))
        except:
            result.append(0)
                
        return result
    
    
    def _arr2str(self, array):
        output = ''
        idx = 0
        
        for item in array:
            if 0 == idx:
                output = output + ('\t0x%02X, ' %(item))
                idx += 1
            elif 15 == idx:
                output = output + ('0x%02X,\n' %(item))
                idx = 0
            else:
                output = output + ('0x%02X, ' %(item))
                idx += 1
                
        return output
    
    
    def h2py(self, file):
        result = self._h2arr(file)
        
        output = 'appkey = [\n'
        output = output + self._arr2str(result)
        output = output + '\n]'       
        
        file='appkey.py'
        dir = dirs.check_addon_data_path()
        file = os.path.join(dir, file)
        
        fh = xbmcvfs.File(file, 'w')
        fh.write(output)
        fh.close()
    
    
    def h2json(self, file):
        result = self._h2arr(file)
        
        list = {'appkey': result}
        print 'list: %s' %list
        
        file='appkey.jsn'
        dir = dirs.check_addon_data_path()
        file = os.path.join(dir, file)
        
        fh = xbmcvfs.File(file, 'w')
        json.dump(list, fh)
        fh.close()
        
    
    def py2h(self, path=None):
        from appkey import appkey
        retval = False
        
        try:
            output = ''
            output = output + '#include <stdint.h>\n'
            output = output + '#include <stdlib.h>\n'
            output = output + 'const uint8_t g_appkey[] = {\n'
            output = output + self._arr2str(appkey)
            output = output + '\n};\n'
            output = output + 'const size_t g_appkey_size = sizeof(g_appkey);'
            
            file='appkey.h'
            if None == path:
                dir = dirs.check_addon_data_path()
                file = os.path.join(dir, file)
            else:
                file = os.path.join(path, file)
            
            fh = xbmcvfs.File(file, 'w')
            fh.write(output)
            fh.close()
        except:
            pass
        
        return retval
        
    
    def json2h(self, path=None):
        retval = False
        
        file = 'appkey.jsn'
        dir = dirs.check_addon_data_path()
        file = os.path.join(dir, file)
        
        try:
            fh = xbmcvfs.File(file, 'r')
            result=json.loads( fh.read() )
            fh.close()
            
            appkey = result['appkey']
            
            output = ''
            output = output + '#include <stdint.h>\n'
            output = output + '#include <stdlib.h>\n'
            output = output + 'const uint8_t g_appkey[] = {\n'
            output = output + self._arr2str(appkey)
            output = output + '\n};\n'
            output = output + 'const size_t g_appkey_size = sizeof(g_appkey);'
        
            file='appkey.h'
            if None == path:
                dir = dirs.check_addon_data_path()
                file = os.path.join(dir, file)
            else:
                file = os.path.join(path, file)
            
            fh = xbmcvfs.File(file, 'w')
            fh.write(output)
            fh.close()
            
            retval = True
        except:
            pass
        
        return retval
        
        
    def get_appkey(self):
        file = 'appkey.jsn'
        dir = dirs.check_addon_data_path()
        file = os.path.join(dir, file)
        
        try:
            fh = xbmcvfs.File(file, 'r')
            result=json.loads( fh.read() )
            fh.close()
            result = result['appkey'] 
        except:
            result = [0]
        
        return result
        
        
    def check_appkey(self):
        result = False
        retval = False
            
        dir = dirs.get_addon_path()
        file = 'resources/libs/utils/appkey.py'
        file = os.path.join(dir, file)
        
        try:
            fh = xbmcvfs.File(file, 'r')
            retval = fh.close()
            if None != retval:
                result = True
        except:
            pass
        
        if False == result:
            appkey = self.get_appkey()
            
            if 321 == len(appkey):
                result = True
                
                output = 'appkey = [\n'
                output = output + self._arr2str(appkey)
                output = output + '\n]'
                
                fh = xbmcvfs.File(file, 'w')
                fh.write(output)
                fh.close()
                
        return result

        
    def import_appkey(self):
        result = False
        dialog = xbmcgui.Dialog()
        #path = expanduser("~")
        #folder = dialog.browse(1,"Token directory","files", '.h', False, False, path)
        file = dialog.browse(1,"Select appkey file" ,"files", ".h")
        if '.h' in file:            
            self.h2json(file)
            result = self.check_appkey()
        
        return result


    def expport_appkey(self):
        dialog = xbmcgui.Dialog()
        #path = expanduser("~")
        #folder = dialog.browse(0,"Token directory","files", '.jsn', False, False, path)
        folder = dialog.browse(0,"Appkey export directory","files")
        if '' != folder:
            retval = dialog.yesno('Export appkey', 'Export appkey to %s ?' %folder)
            if True == retval: 
                self.json2h(folder)
