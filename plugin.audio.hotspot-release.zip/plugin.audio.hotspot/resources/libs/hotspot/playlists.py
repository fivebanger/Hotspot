
import urllib2
import json
import xbmcaddon
import spotipy
from spotipy import oauth2
from token_handler import TokenHandler


web_api = True

    
class Playlist():
    
    def __init__(self):
        addon_id = 'plugin.audio.hotspot'
        self.addon = xbmcaddon.Addon(addon_id)
        

    def load_playlists(self):
        if False == web_api:
            server_port = self.addon.getSetting('internal_server_port')
            response = urllib2.urlopen('http://127.0.0.1:'+server_port+'/playlists')
            playlists = response.read()
            playlists = json.loads(playlists)
        else:
            cl_id  = self.addon.getSetting('client_id')
            cl_sec = self.addon.getSetting('client_secret')
            th = TokenHandler()
            cache_path = th.get_token_path()
            scope = th.get_token_scope()
            auth = oauth2.SpotifyOAuth(cl_id, cl_sec, '', None, scope, cache_path)
            token_info = auth.get_cached_token()
            token = token_info['access_token']
            sp = spotipy.Spotify(auth=token)
            results = sp.current_user_playlists()
            playlists = results
            while results['next']:
                results = sp.next(results)
                playlists['items'].extend(results['items'])
        
        return playlists


    def load_tracks(self, pos, user):
        if False == web_api:
            show_unavail = self.addon.getSetting('show_unavailable')
            server_port = self.addon.getSetting('internal_server_port')
            response = urllib2.urlopen('http://127.0.0.1:'+server_port+'/playlists/?pos='+str(pos)+'&show_unavail='+show_unavail)
            playlists = response.read()
            playlists = json.loads(playlists)
        else:
            cl_id  = self.addon.getSetting('client_id')
            cl_sec = self.addon.getSetting('client_secret')
            th = TokenHandler()
            cache_path = th.get_token_path()
            scope = th.get_token_scope()
            auth = oauth2.SpotifyOAuth(cl_id, cl_sec, '', None, scope, cache_path)
            token_info = auth.get_cached_token()
            token = token_info['access_token']
            sp = spotipy.Spotify(auth=token)
            results = sp.user_playlist_tracks(user, pos)
            playlists = results
            while results['next']:
                results = sp.next(results)
                playlists['items'].extend(results['items'])        
        
        return playlists
    