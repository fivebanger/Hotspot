
import xbmc
import xbmcaddon
from url_utils import Urlbuild


log_level = xbmc.LOGDEBUG

addon = xbmcaddon.Addon(id='plugin.audio.hotspot')

def _get_playlist(pl_type, new=False):
    pl = xbmc.PlayList(pl_type)
    if new:
        pl.clear()
    return pl

class HotspotPlayer(xbmc.Player):
    REPORTING_TIME = 30

    def __init__(self, *args, **kwargs):
        xbmc.Player.__init__(self)
        #self.et = kwargs['et']
        self.pl = _get_playlist(xbmc.PLAYLIST_MUSIC, True)
        self.ended = False
        self.track_reported = False
        self.track_id_lookup = {}
    
    def play_track(self, track_id):
        #Addon.log('Player - play')
        msg = 'Player, play'
        xbmc.log(addon.getAddonInfo('name') + ': ' + 
                 msg.encode('ascii','ignore'), log_level) 
            
        xbmc_pl = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        xbmc_pl.clear()
        #xbmc_pl.add(url, listitem=li)
        
        url_build = Urlbuild('')
        server_port = '8081'
        index = 1
        duration_ms = 0
        url = url_build.proxy_track(server_port, track_id, index, duration_ms)
        xbmc_pl.add(url)
        #xbmc_pl.add(url, listitem=li)
        
        #self._create_album_track_list(tracks, album_image, add=True, remove=False, play=True, album_name=album_name)
        #return super(HotspotPlayer, self).play()
        
        self.play(xbmc_pl)
        
        while not self.ended:
            xbmc.sleep(1000)
        
        
    def onPlayBackStopped(self):
        print 'onPlayBackStopped'
        self.ended = True
        

    def onPlayBackSeek(self, time, seekOffset):
        msg = 'onPlayBackSeek, play'
        xbmc.log(addon.getAddonInfo('name') + ': ' + 
                 msg.encode('ascii','ignore'), log_level) 
        print str(time) 
        print str(seekOffset) 
        #self.ended = True
        time = self.getTime()
        #self.seekTime(0)
        self.play()
        
    def onPlayBackSeekChapter(self, chapter):
        msg = 'onPlayBackSeekChapter, play'
        xbmc.log(addon.getAddonInfo('name') + ': ' + 
                 msg.encode('ascii','ignore'), log_level) 
        return super(HotspotPlayer, self).pause()
        
    def onPlayBackSpeedChanged(self, speed):
        msg = 'onPlayBackSpeedChanged, play'
        xbmc.log(addon.getAddonInfo('name') + ': ' + 
                 msg.encode('ascii','ignore'), log_level) 
        return super(HotspotPlayer, self).pause()
    '''        
    def seekTime(self, pTime):
        msg = 'seekTime, play'
        xbmc.log(addon.getAddonInfo('name') + ': ' + 
                 msg.encode('ascii','ignore'), log_level) 
        return super(HotspotPlayer, self).pause()
    '''

    ### function overrides #
    def playnext(self):
        print 'playnext'
        #Addon.log('Player - playnext')
        return super(HotspotPlayer, self).playnext()

    def playprevious(self):
        #Addon.log('Player - playprevious')
        return super(HotspotPlayer, self).playprevious()

    def playselected(self):
        #Addon.log('Player - playselected')
        return super(EightTracksPlayer, self).playselected()

    def stop(self):
        print 'stop'
        #Addon.log('Player - stop')
        return super(HotspotPlayer, self).stop()

    def pause(self):
        print 'pause'
        #Addon.log('Player - pause')
        return super(HotspotPlayer, self).pause()
