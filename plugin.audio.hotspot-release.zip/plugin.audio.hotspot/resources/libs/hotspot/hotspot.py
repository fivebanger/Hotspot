
import xbmcplugin
import xbmcaddon
import xbmcgui
import xbmc
import xbmcvfs
import os
import urllib
import urllib2
import socket
import time
import json
from keyboard import Keyboard
from context_menu import Contextmenu
from url_utils import Urlbuild
from list_item import ListItem
import spotipy
import dirs
from playlists import Playlist
from data import HtsptData
from fanart import Fanart
from token_handler import TokenHandler
from appkey_handler import AppkeyHandler


log_level = xbmc.LOGDEBUG


class Hotspot():
    
    def __init__(self, base_url, addon_handle):
        self.base_url = base_url
        self.addon_handle = addon_handle
        
        addon_id   = 'plugin.audio.hotspot'
        self.addon = xbmcaddon.Addon(addon_id)
        
        self.use_fanart       = self.addon.getSetting('use_fanart')
        self.show_unavailable = self.addon.getSetting('show_unavailable')
        self.server_port_auto = self.addon.getSetting('internal_server_port_auto')
        self.server_port      = self.addon.getSetting('internal_server_port')
        
        self.token        = self.get_token()
        self.sp           = spotipy.Spotify(self.token)
        self.limit        = 50
        self.result_limit = self.limit
        self.use_web_api  = True
        self.start_auto   = False
        
        self._check_country()
        self._check_appkey()
        self._check_proxy()
        
      
    def _check_country(self):
        self.country = self.addon.getSetting('country')
        if '' == self.country:
            current_user = self.sp.current_user()
            self.country = current_user['country']
            self.addon.setSetting('country', self.country)
        
      
    def _check_appkey(self):
        ah = AppkeyHandler()
        result = ah.check_appkey()
        
        if False == result:
            dlg = xbmcgui.Dialog()
            retval = dlg.yesno('Appkey error', 'No valid appkey found. Import appkey?', nolabel='ok', yeslabel='cancel')
            if True == retval: 
                #cancel
                exit()
                
            result = ah.import_appkey()
            if False == result:
                dlg.ok('Appkey import error', 'No valid appkey found.')
                exit()


    def _check_connection(self, server_port='0'):
        #check if there is a open port
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex(('127.0.0.1', int(server_port)))
        
        if result == 0:
            try:
                #check if Hotspot is running on open port
                response = urllib2.urlopen('http://127.0.0.1:'+server_port+'/useragent')
                useragent = response.read()
                if useragent == 'Hotspot':
                    return True
            except:
                pass
            
        return False   
    
    
    def _find_free_port(self, current_port):
        port = int(current_port)
        reset = True
        
        if 'true' == self.server_port_auto:
            port_min = 8081
            port_max = 8111
        else:
            port_min = int(current_port)
            port_max = int(current_port)
        
        while True:
            #check if current port is already open
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            result = sock.connect_ex(('127.0.0.1', port))
            
            if result == 0:
                try:
                    #check if Hotspot is running on open port
                    response = urllib2.urlopen('http://127.0.0.1:%s/useragent' % port)
                    useragent = response.read()
                    if useragent == 'Hotspot':
                        return True
                except:
                    #port is in use by another service
                    if True == reset:
                        port = port_min
                    pass
            else:
                #free port found
                sock.close()
                break
            
            
            if port >= port_max:
                #no free port found
                xbmc.log( 'Hotspot: No free proxy port found.', xbmc.LOGERROR)
                dlg = xbmcgui.Dialog()
                dlg.ok('Hotspot error', 'Please specify a free proxy port in add-on settings.')
                self.addon.openSettings()
                exit()
            elif True == reset:
                reset = False
            else:
                port = port + 1
        
        if port != int(current_port):
            self.addon.setSetting('internal_server_port', str(port))
            self.server_port = self.addon.getSetting('internal_server_port')

        return False
        
        
    def _check_proxy(self):    
    
        retval = self._find_free_port(self.server_port)
        #retval = self._check_connection(self.server_port)
        
        if False == retval:            
            Connect = False
            # start Hotspot proxy
            addon_path = self.addon.getAddonInfo('path')
            path = os.path.join(addon_path, "proxy.py")
            xbmc.executebuiltin('XBMC.RunScript('+path+')')
            xbmc.log( 'Hotspot: Start server on port %s' %self.server_port, xbmc.LOGNOTICE )
            
            time.sleep(2)
            
            while xbmc.getCondVisibility('Window.IsActive(busydialog)'):
                time.sleep(.5)
            
            #check again if Hotspot proxy is up
            if True == self._check_connection(self.server_port):
                # Hotspot proxy is already up
                Connect = True
                
            if False == Connect:
                xbmc.log( 'Hotspot connection error, Can\'t connect to Spotify.', xbmc.LOGERROR)
                dlg = xbmcgui.Dialog()
                dlg.ok('Hotspot connection error', 'Can\'t connect to Spotify.')
                exit()
            else:
                xbmc.log( 'Hotspot: Connected to Spotify.', xbmc.LOGNOTICE )
        else:
            self.start_auto = False
                
                
    def get_token(self):
        th = TokenHandler()
        return th.get_token()


    def _search_item(self, search_str = '', type='tracks', offset=0):
        if type == 'artists':
            list = {"artists": []}
            query='artist'
        elif type == 'albums':
            list = {"albums": []}
            query='album'
        elif type == 'tracks':
            list = {"tracks": []}
            query='track'
        else:
            return
        
        max_search = int(self.addon.getSetting('max_search'))
        max_items = (max_search+1)*10
        index = 0
        offset = int(offset)
        search = True
        
        if (search_str != '') and (search_str != None):
            while search == True:
                unique = set()  # skip duplicate items
                results = self.sp.search(query+':'+search_str, self.limit, offset, query, self.country)
                items = results[type]['items']
                if len(items) > 0:
                    for item in items:
                        if index < max_items:
                            add=True
                            if type != 'artists':
                                if self.country not in item['available_markets']:
                                    add=False
                            if add == True:
                            #    name = item['name']
                                id = item['id']
                                if not id in unique:
                                    list[type].append(item)
                                    index += 1
                                    unique.add(id)
                            #       unique.add(name)
                        else:
                            search = False
                            
                    if results[type]['next'] == None:
                        search = False
                        offset = 0
                    else:
                        offset = max_items
                else:
                    search = False
        
        #pagination = True
        pagination = False
        if pagination == False:
            offset = 0

        return list, offset        
        
    def _get_icon(self, images):
        
        if len(images) >= 2:
            icon = images[1]['url']
        if len(images) >= 1:
            icon = images[0]['url']
        else:
            icon = 'DefaultArtist.png'
            
        return icon
            
    def _create_artist_list(self, artists=[], add=False, remove=False, mode='', search_str='', offset=0, list_index=1, filename=''):
        list_item = ListItem(self.addon_handle, self.base_url)

        if len(artists) == 0:
            list_item.end_of_directory()
            return
    
        for artist in artists:
            artist_name = artist['name']
            artist_id = artist['id']
            icon = self._get_icon(artist['images'])
            
            if artist['popularity']:
                popularity = artist['popularity']
            else:
                popularity = '1'

            list_item.cm_artist(add, remove, artist_id, filename)
            list_item.addon_path({'mode': 'show_artist_albums', 'artist_id': artist_id})
            list_item.artist(artist_name, list_index, icon, len(artists))

            list_index += 1
                    
        if offset != 0:
            list_item.cm_none()
            list_item.addon_path({'mode': mode, 'search_str': search_str, 'offset': offset, 'list_index': list_index})
            list_item.next()
        
        list_item.end_of_directory()
        

    
    def _create_album_list(self, albums, add=False, remove=False, mode='', search_str='', offset=0, list_index=1, filename=''):
        list_item = ListItem(self.addon_handle, self.base_url)
        
        data = HtsptData()
        results_fanart = data.load_list('fanart', 'fanart')
        artist_urls = results_fanart['artist_urls']
        
        if len(albums) == 0:
            list_item.end_of_directory()
            return
        
        unique = set()  # skip duplicate items
        for album in albums:
            album_name = album['name'] 
            album_id = album['id']
            
            if not album_name.lower() in unique:
                icon = self._get_icon(album['images'])
                user = 'void'
        
                if album.get('album_type'):
                    album_type = album['album_type']
                    album_type = album_type.lower()
                    if 'album' == album_type or 'single' == album_type:
                        artist = album['tracks']['items'][0]['artists'][0]['name']
                        artist_id = album['tracks']['items'][0]['artists'][0]['id']
                        release = int(album['release_date'][:4])
                        background_id = artist_id
                    else:
                        #playlist proxy server
                        artist = 'Various'
                        artist_id = ''
                        background_id = '0'
                else:
                    #playlist web api
                    album['album_type'] = 'playlist'
                    artist = 'Various'
                    artist_id = ''
                    background_id = ''
                    user = album['owner']['id']
                    user = user.encode('utf-8')
                    
                if 'playlist' == album['album_type']:
                    #url = url_build.addon({'mode': 'my_playlists_tracks', 'pos': album_id, 'user': user})
                    addon_path = {'mode': 'my_playlists_tracks', 'pos': album_id, 'user': user}
                    cm_type='playlist'
                else:
                    #url = url_build.addon({'mode': 'show_album_tracks', 'album_id': album_id, 'album_image': icon, 'album_name': album_name.encode('utf-8')})
                    addon_path = {'mode': 'show_album_tracks', 'album_id': album_id, 'album_image': icon, 'album_name': album_name.encode('utf-8')}
                    cm_type='albums'
                
                if (background_id in artist_urls) and ('true' == self.use_fanart):
                    fanart = artist_urls[background_id]
                else:
                    fanart = ''

                list_item.cm_album(cm_type, add, remove, artist_id, album_id, album_name.encode('utf-8'), icon, user, filename)
                list_item.addon_path(addon_path)
                list_item.album(artist, album_name, list_index, icon, len(albums), fanart)
                
                list_index += 1
        
                unique.add(album_name.lower())
                    
        if offset != 0:
            list_item.cm_none()
            list_item.addon_path({'mode': mode, 'search_str': search_str, 'offset': offset, 'list_index': list_index})
            list_item.next()

        list_item.end_of_directory()


    def _lookup_albums(self, artist_id, album_type, offset, list_index):
        offset = int(offset)
        list_index = int(list_index)
        mode = 'show_%s_next' %album_type

        results = self.sp.artist_albums(artist_id, album_type, self.country, self.limit, offset)
        albums = results
#         while results['next']:
#             results = self.sp.next(results)
#             albums['items'].extend(results['items'])
        
        if results['next']:
            offset = int(results['offset']) + self.limit
        else:
            offset = 0
        
        albums_unified=albums['items']
            
        #unify albums list
        for album in albums_unified:
            album['tracks'] = {}
            album['tracks']['items'] = []
            album['tracks']['items'].append({'artists': album['artists']})
            album['tracks']['items'][0]['artists'][0]['name'] = ''
            album['release_date'] = '0000-00-00'
        
        self._create_album_list(albums_unified, add=True, mode=mode, search_str=artist_id, offset=offset, list_index=list_index)

    
    def _create_track_list(self, tracks=[], add=False, remove=False, play=False, mode='', search_str='', offset=0, list_index=1, filename=''):
        list_item = ListItem(self.addon_handle, self.base_url)
        
        data = HtsptData()
        results_fanart = data.load_list('fanart', 'fanart')
        artist_urls = results_fanart['artist_urls']

        if len(tracks) == 0:
            list_item.end_of_directory()
            return

        tmp_filename = 'tmp_tracks'
        tmp_tracks = {'tracks': tracks}
        data = HtsptData()
        data.save_file(tmp_filename, tmp_tracks, path='profile')
    
        for track in tracks:
            artist_name = track['artists'][0]['name']
            artist_id = track['artists'][0]['id'] 
            album_name = track['album']['name']
            album_id = track['album']['id'] 
            track_name = track['name']
            track_id = track['id']
            track_no = track['track_number']
            duration_ms = int(track['duration_ms'])
            duration = duration_ms/1000
            available_markets = track['available_markets']
            if 0 == len(available_markets):
                available_markets = self.country
            
            if (self.country in available_markets) or ('true' == self.show_unavailable):
                #add track to list
                icon = self._get_icon(track['album']['images'])
                
                if (artist_id in artist_urls) and ('true' == self.use_fanart):
                    fanart = artist_urls[artist_id]
                else:
                    fanart = ''

                list_item.cm_track(add, remove, artist_id, album_id, track_id, filename)
                list_item.proxy_path(self.server_port, track_id, list_index, duration_ms) 
                list_item.track(artist_name, album_name, track_name, list_index, track_no, duration, icon, play, len(tracks), fanart)
                    
                list_index += 1
                    
        if offset != 0:
            list_item.cm_none()
            list_item.addon_path({'mode': mode, 'search_str': search_str, 'offset': offset, 'list_index': list_index})
            list_item.next()
            
        list_item.end_of_directory()


    def _lookup_tracks(self, track_id):
        tracks = self.sp.tracks([track_id])
        return tracks

   
    def main_menu(self):
        list_item = ListItem(self.addon_handle, self.base_url)
                
        name = 'Explore Spotify'
        list_item.cm_none()
        list_item.addon_path({'mode': 'spotify_menu'})
        list_item.menu('spotify_menu', name)
                
        name = 'Recently'
        list_item.cm_menu('recently_menu')
        list_item.addon_path({'mode': 'recently_menu'})
        list_item.menu('recently_menu', name)
        
        #add category list items
        self._categories(list_item)
        
#         name = 'My Artists from Fanart'
#         list_item.cm_none()
#         list_item.addon_path({'mode': 'get_artists_from_fanart'})
#         list_item.menu('main_menu', name)
        
        list_item.end_of_directory()

        if True == self.start_auto:
            self.recently_items('played', True)


    def _load_categories(self):
        data = HtsptData()
        type = 'categories'
        filename = 'categories'
        return data.load_list(type, filename)


    def _save_categories(self, list, list_bak):
        data = HtsptData()
        type = 'categories'
        filename = 'categories'
        return data.save_list(type, filename, list, list_bak)

        
    def _categories(self, list_item):
        result = self._load_categories()
            
        for category in result['categories']:            
            name = category['name']
            mode = category['mode']
            type = category['type']
            filename = category['filename']

            list_item.cm_menu('main_menu', name, type, filename=filename)
            list_item.addon_path({'mode': mode, 'foldername': name, 'filename': filename})
            list_item.menu('main_menu', name)
    
    
    def _request_category_name(self, text=''):

        result = self._load_categories()
        search = True
        name = None
        
        while search:
            search = False
            keyboard = Keyboard()
            name = keyboard.get_text('Enter new name', text=text)
            if name == '' or name == text:
                return None
            
            for item in result['categories']:
                if name == item['name']:
                    #name already exists
                    dialog = xbmcgui.Dialog()
                    dialog.ok('Name error', 'Name already exists')

                    search = True
                    break
        
        return name
    
    
    def _get_categories_by_type(self, type):
        items = []
        result = self._load_categories()
        for item in result['categories']:
            if type == item['type']:
                items.append(item)
        
        if 0 == len(items):
            items = None
           
        return items
        

    def category_add_item(self, type, id):
        
        items = self._get_categories_by_type(type)
        
        if None == items:
            return
        names = []
        for item in items:
            names.append(item['name'])
        
        dialog = xbmcgui.Dialog()
        idx = dialog.select('Add to Category', names)
        
        if -1 == idx:
            #cancel
            return
        
        filename = items[idx]['filename']
        self.add_to_list(id, type, filename)
        

    def category_add(self):
        type = ''
        dialog = xbmcgui.Dialog()
        
        idx = dialog.select('New Category', ['Artists', 'Albums', 'Tracks'])
        if idx == 0:
            type = 'artists'
        elif idx == 1:
            type = 'albums'
        elif idx == 2:
            type = 'tracks'
        else:
            return
        
        name = self._request_category_name()
        if None == name:
            return

        filename = str(int(time.time()))
        
        new_item = {'type': type, 'mode': 'categories', 'name': name, 'filename': filename, 'lock': False}
        
        result = self._load_categories()
        result_bak = result
        result['categories'].append(new_item)
        self._save_categories(result, result_bak)
        xbmc.executebuiltin('Container.Refresh')
    

    def category_rename(self, current_name):
        result =  self._load_categories()
        result_bak = result

        for item in result['categories']:
            if current_name == item['name']:
                if True == item['lock']:
                    #locked item cannot get renamed
                    dialog = xbmcgui.Dialog()
                    dialog.ok('Rename error', 'Cannot rename %s' %current_name)
                    return
                
                name = self._request_category_name(current_name)
                if None == name:
                    return
                
                item['name'] = name
                break
 
        self._save_categories(result, result_bak) 
        xbmc.executebuiltin('Container.Refresh')
        
        
    def category_move(self, name):
        list = []
        dialog = xbmcgui.Dialog()

        result = self._load_categories()
        result_bak = result
        for item in result['categories']:
            list_name = item['name']
            list.append(list_name)
            if name == item['name']:
                move_item = item

        new_index = dialog.select('Move Category', list)
        result['categories'].remove(move_item)
        result['categories'].insert(new_index, move_item)
        
        self._save_categories(result, result_bak)   
        xbmc.executebuiltin('Container.Refresh')
    
    
    def category_delete(self, name):
        result = self._load_categories()
        result_bak = result
        
        for item in result['categories']:
            if name == item['name']:
                if True == item['lock']:
                    #locked item cannot get removed
                    dialog = xbmcgui.Dialog()
                    dialog.ok('Delete error', 'Cannot delete %s' %name)
                    return
                
                dialog = xbmcgui.Dialog()
                retval = dialog.yesno('Delete category', 'Delete category?')
                if False == retval: 
                    return
                
                #delete item
                result['categories'].remove(item)
                filename = item['filename']
                break

        self._save_categories(result, result_bak)
        xbmc.executebuiltin('Container.Refresh')


    def categories(self, file, type=''):
        result = self._load_categories()
        type = '' 
        filename = ''
        for category in result['categories']:  
            filename = category['filename']
            if filename == file:
                type = category['type']
                break

        data = HtsptData()
        results=data.load_file(filename)
        
        if results:
            if type == 'artists':
                artists=results['artists']
                self._create_artist_list(artists, remove=True, filename=filename)
            elif type == 'albums':
                albums=results['albums']
                albums.sort(key=lambda album:album['artists'][0]['name'].lower())
                self._create_album_list(albums, remove=True, filename=filename)
            elif type == 'tracks':
                tracks=results['tracks']
                tracks.sort(key=lambda track:track['name'].lower())
                self._create_track_list(tracks, remove=True, filename=filename)
        else:
            #create an empty list
            list_item = ListItem(self.addon_handle)
            list_item.end_of_directory()


    def recently_menu(self):
        list_item = ListItem(self.addon_handle, self.base_url)
                
        name = 'Recently Played'
        list_item.cm_none()
        list_item.addon_path({'mode': 'recently_items', 'type': 'played'})
        list_item.menu('spotify_menu', name)
                
        name = 'Recently Added Artists'
        list_item.cm_none()
        list_item.addon_path({'mode': 'recently_items', 'type': 'artists'})
        list_item.menu('spotify_menu', name)
                
        name = 'Recently Added Albums'
        list_item.cm_none()
        list_item.addon_path({'mode': 'recently_items', 'type': 'albums'})
        list_item.menu('spotify_menu', name)
                
        name = 'Recently Added Tracks'
        list_item.cm_none()
        list_item.addon_path({'mode': 'recently_items', 'type': 'tracks'})
        list_item.menu('spotify_menu', name)
        
        list_item.end_of_directory()
        
        
    def recently_items(self, type, play=False):
        if type == 'artists':
            filename = 'recently_artists'
        elif type == 'albums':
            filename = 'recently_albums'
        elif type == 'tracks':
            filename = 'recently_tracks'
        elif type == 'played':
            filename = 'recently_played'
        else:
            xbmc.log('Hotspot: wrong type %s' % type, log_level)
            return
        
        data = HtsptData()
        if type != 'played':
            results = data.load_list(type, filename)
        else:
            type = 'tracks'
            results=data.load_list('tracks', filename, 'profile')
            
        if type == 'artists' and results:
            artists=results['artists']
            self._create_artist_list(artists, filename=filename)
        if type == 'albums' and results:
            albums=results['albums']
            self._create_album_list(albums, filename=filename)
        if type == 'tracks' and results:
            tracks=results['tracks']
            if True == play:
                xbmc_pl = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
                xbmc_pl.clear()
                self._create_track_list(tracks, play=True, filename=filename)
                player = xbmc.Player()
                player.play(xbmc_pl)
            else:
                self._create_track_list(tracks, filename=filename)

    
    def add_to_resently_list(self, item_add, type):
        if type == 'artists':
            filename = 'recently_artists'
        elif type == 'albums':
            filename = 'recently_albums'
        elif type == 'tracks':
            filename = 'recently_tracks'
        elif type == 'played':
            filename = 'recently_tracks'
        else:
            xbmc.log('Hotspot: wrong type %s' % type, log_level)
            return
        
        data = HtsptData()
        if type != 'played':
            list = data.load_list(type, filename)
        else:
            type = 'tracks'
            list = data.load_list(type, filename)
        list_bak = list

        for item in list[type]:
            if item['id'] == item_add['id']:
                list[type].remove(item)
        list[type].insert(0, item_add)
        list[type] = list[type][0:10]
        
        data.save_list(type, filename, list, list_bak)


    def on_play_song(self, track_id):
        old_filename = 'tmp_tracks'
        new_filename = 'recently_played'
        data = HtsptData()
        data.rename_file(old_filename, new_filename, backup=False, path='profile')


    def spotify_menu(self):
        list_item = ListItem(self.addon_handle, self.base_url)
        
        name = 'Search Artists'
        list_item.cm_none()
        list_item.addon_path({'mode': 'search_artists'})
        list_item.menu('main_menu', name)
        
        name = 'Search Albums'
        list_item.cm_none()
        list_item.addon_path({'mode': 'search_albums'})
        list_item.menu('main_menu', name)
        
        name = 'Search Tracks'
        list_item.cm_none()
        list_item.addon_path({'mode': 'search_tracks'})
        list_item.menu('main_menu', name)
        
        name = 'My Spotify Playlists'
        list_item.cm_menu('spotify_menu', name, 'playlists')
        list_item.addon_path({'mode': 'my_playlists', 'offset': 0, 'list_index': 1})
        list_item.menu('spotify_menu', name)
        
        name = 'My Spotify Albums'
        list_item.cm_menu('spotify_menu', name)
        list_item.addon_path({'mode': 'current_user_saved_albums', 'offset': 0, 'list_index': 1})
        list_item.menu('spotify_menu', name)
        
        name = 'My Spotify Tracks'
        list_item.cm_menu('spotify_menu', name)
        list_item.addon_path({'mode': 'current_user_saved_tracks', 'offset': 0, 'list_index': 1})
        list_item.menu('spotify_menu', name)
        
        name = 'New Releases'
        list_item.cm_none()
        list_item.addon_path({'mode': 'new_releases'})
        list_item.menu('spotify_menu', name)
        
        name = 'Genres And Moods'
        list_item.cm_none()
        list_item.addon_path({'mode': 'genres'})
        list_item.menu('spotify_menu', name)
        
        name = 'My Top Artists'
        list_item.cm_none()
        list_item.addon_path({'mode': 'current_user_top_artists'})
        list_item.menu('spotify_menu', name)
        
        name = 'My Top Tracks'
        list_item.cm_none()
        list_item.addon_path({'mode': 'current_user_top_tracks'})
        list_item.menu('spotify_menu', name)
        
        name = 'My Recommended Albums'
        list_item.cm_none()
        list_item.addon_path({'mode': 'recommend_albums', 'seed': '0'})
        list_item.menu('spotify_menu', name)
        
        name = 'My Recommended Tracks'
        list_item.cm_none()
        list_item.addon_path({'mode': 'recommend_tracks', 'seed': '0'})
        list_item.menu('spotify_menu', name)
        
        list_item.end_of_directory()  
            
            
    def current_user_saved_albums(self, offset, list_index):
        offset = int(offset)
        list_index = int(list_index)
        
        #get user's albums
        results = self.sp.current_user_saved_albums(self.limit, offset=offset)
        albums = results
        #while results['next']:
        #    results = self.sp.next(results)
        #    albums['items'].extend(results['items'])
    
        mode = 'current_user_saved_albums'
        if results['next']:
            offset = int(results['offset']) + int(self.limit)
        else:
            offset = 0
        
        albums=albums['items']
        
        #unify albums list
        albums_unified = []
        for album in albums:
            albums_unified.append(album['album'])
        
        #sort list by artists
        albums_unified.sort(key=lambda album:album['artists'][0]['name'].lower())
        self._create_album_list(albums_unified, add=True, mode=mode, offset=offset, list_index=list_index) 
        
    
    def current_user_saved_albums_import(self, filename):
        progress = 1
        dialog = xbmcgui.Dialog()
        retval = dialog.yesno('Import Spotify albums', 'Import your saved albums from Spotify?')
        if False == retval: 
            return
        
        dialog = xbmcgui.DialogProgress()
        dialog.create('Import Spotify albums')
        dialog.update(progress, 'Fetching album-list from Spotify')
            
        #get user's albums
        results = self.sp.current_user_saved_albums(self.limit)
        albums = results
        while results['next']:
            offset = int(results['offset']) + int(self.limit)
            total = int(results['total'])
            xbmc.log('Hotspot: offset: %s' %offset, xbmc.LOGERROR)
            xbmc.log('Hotspot: total: %s' %total, xbmc.LOGERROR)
            progress = ( (offset * 100) / total )
            dialog.update(progress, 'Fetching album-list from Spotify')
            
            results = self.sp.next(results)
            albums['items'].extend(results['items'])
            
            if dialog.iscanceled()==True:
                return
        
        progress = 100
        dialog.update(progress, 'Fetching album-list from Spotify')
            
        albums=albums['items']
    
        #temporarily disable fanart to speed up add_to_list() 
        self.use_fanart = 'false'
        type = 'albums'
        index = 1
        album_ids = []
        
        data = HtsptData() 
        list = data.load_list(type, filename)
        
        for album in albums:
            if dialog.iscanceled()==True:
                return
            
            id = album['album']['id']
            name = album['album']['name']
            
            #check if spotify album is already in my albums list
            add = True
            for item in list[type]:
                if item['id'] == id:
                    add = False
                    break
            
            if True == add:
                album_ids.append(id)
                           
            index += 1
        
        dialog.close()
        
        self._add_to_list_multiple(album_ids, type, filename)
        self.use_fanart = self.addon.getSetting('use_fanart')
        if ('true' == self.use_fanart):
            dialog = xbmcgui.Dialog()
            retval = dialog.yesno('Update Fanart', 'Update Fanart?')
            if True == retval: 
                self.update_fanart(type, filename)


    def current_user_saved_tracks(self, offset, list_index):
        #obsolete! takes definitely to long to load...
        offset = int(offset)
        list_index = int(list_index)
        
        #get user's tracks
        results = self.sp.current_user_saved_tracks(self.limit, offset=offset)
        tracks = results
        #while results['next']:
        #    results = self.sp.next(results)
        #    tracks['items'].extend(results['items'])
        
        mode = 'current_user_saved_tracks'
        if results['next']:
            offset = int(results['offset']) + int(self.limit)
        else:
            offset = 0
        
        tracks=tracks['items']
        
        #unify track list
        tracks_unufied = []
        for track in tracks:
            tracks_unufied.append(track['track'])
        
        self._create_track_list(tracks_unufied, remove=True, mode=mode, offset=offset, list_index=list_index)
        
    
    def new_releases(self):
        results = self.sp.new_releases(self.country, self.limit)
        releases = results
        while results['albums']['next']:
            current_offset = int(results['albums']['offset'])
            if current_offset >= self.result_limit:
                break
            results = self.sp.next(results['albums'])
            releases['albums']['items'].extend(results['albums']['items'])
        
        albums=releases['albums']['items']
        
        #unify albums list
        for album in albums:
            album['tracks'] = {}
            album['tracks']['items'] = []
            album['tracks']['items'].append({'artists': album['artists']})
            album['release_date'] = '0000-00-00'

        self._create_album_list(albums, add=True)
        
        
    def current_user_top_artists(self):
        time_range='short_term' 
        #time_range='medium_term'
        #time_range='long_term'
        results = self.sp.current_user_top_artists(self.limit, time_range=time_range)
        artists = results['items']
        self._create_artist_list(artists, add=True)
        

    def current_user_top_tracks(self):
        #time_range='short_term' 
        #time_range='medium_term'
        time_range='long_term'
        results = self.sp.current_user_top_tracks(self.limit, time_range=time_range)
        tracks = results['items']
        
        #unify track list
        for track in tracks:
            track['available_markets'] = ''

        self._create_track_list(tracks, add=True)
        

    def recommend_albums(self, seed='0'):
        
        seed_artists = []
            
        if '0' == seed:
            limit = 5
            #time_range='short_term' 
            #time_range='medium_term'
            time_range='long_term'
            results = self.sp.current_user_top_artists(limit, time_range=time_range)
            artists = results['items']
            
            #get artist seeds based on users top artists
            for artist in artists:
                artist_id = artist['id']
                seed_artists.append(artist_id)
        else:
            seed_artists.append(seed)
            
        seed_genres = []
        seed_genres.append('soul')

        results = self.sp.recommendations(seed_artists=seed_artists, limit=self.limit, country=self.country)
        albums = results['tracks']
        
        #unify albums list
        albums_unified = []
        for album in albums:
            album['album']['tracks'] = {}
            album['album']['tracks']['items'] = []
            album['album']['tracks']['items'].append({'artists': album['artists']})
            album['album']['release_date'] = '0000-00-00'
            albums_unified.append(album['album'])
            
        self._create_album_list(albums_unified, add=True)
        

    def recommend_genre(self, seed):
            
        seed_genres = []
        seed_genres.append(seed)

        results = self.sp.recommendations(seed_genres=seed_genres, limit=self.limit, country=self.country)
        albums = results['tracks']
        
        #unify albums list
        albums_unified = []
        for album in albums:
            album['album']['tracks'] = {}
            album['album']['tracks']['items'] = []
            album['album']['tracks']['items'].append({'artists': album['artists']})
            album['album']['release_date'] = '0000-00-00'
            albums_unified.append(album['album'])

        self._create_album_list(albums_unified, add=True)
        

    def recommend_tracks(self, seed='0'):
        
        seed_tracks = []
        
        if '0' == seed:
            limit = 5
            time_range='short_term' 
            #time_range='medium_term'
            #time_range='long_term'
            results = self.sp.current_user_top_tracks(limit, time_range=time_range)
            tracks = results['items']
            
            #get track seeds based on users top tracks
            for track in tracks:
                track_id = track['id']
                seed_tracks.append(track_id)
        else:
            seed_tracks.append(seed)

        results = self.sp.recommendations(seed_tracks=seed_tracks, limit=self.limit)
        tracks = results['tracks']
        self._create_track_list(tracks, add=True)
    
    
    def _create_genres_list(self, genres, remove=False, add=False, list_index=1):
        list_item = ListItem(self.addon_handle, self.base_url)
        
        if len(genres) > 0:
            index=1
            for genre in genres:
                genre_name = genre['name']
                genre_id = genre['id']
                icon = self._get_icon(genre['icons'])
                
                list_item.cm_menu('category_menu', id=genre_id)
                list_item.addon_path({'mode': 'show_genre_items', 'genre_id': genre_id})
                list_item.menu('genre', genre_name, icon=icon)
            
        list_item.end_of_directory()
    
    
    def genres(self):
        results = self.sp.categories(self.country, limit=self.limit)
        genres = results
        while results['categories']['next']:
            current_offset = int(results['categories']['offset'])
            results = self.sp.next(results['categories'])
            genres['categories']['items'].extend(results['categories']['items'])
        
        genres = genres['categories']['items']
        self._create_genres_list(genres)
        
        
    def genre_items(self, genre_id):
        results = self.sp.category_playlists(genre_id, self.country, self.limit)
        playlists = results
        while results['playlists']['next']:
            current_offset = int(results['playlists']['offset'])
            if current_offset >= self.result_limit:
                break
            results = self.sp.next(results['playlists'])
            playlists['playlists']['items'].extend(results['playlists']['items'])
        
        playlists = playlists['playlists']['items']
        self._create_album_list(playlists)
        
    
    def my_playlists(self, offset=0, list_index=1):
        
        mode = 'my_playlists'
        
        if False == self.use_web_api:
            offset = 0
            list_index = 1
            
            pl = Playlist()
            playlists = pl.load_playlists()
            playlists = playlists['items']
        else:
            offset = int(offset)
            list_index = int(list_index)
            pagination = True
            
            results = self.sp.current_user_playlists(self.limit, offset)
            playlists = results
            if False == pagination:
                while results['next']:
                    results = self.sp.next(results)
                    playlists['items'].extend(results['items'])
            else:
                if results['next']:
                    offset = int(results['offset']) + int(self.limit)
                else:
                    offset = 0
                
            playlists = playlists['items']
                
        self._create_album_list(playlists, mode=mode, offset=offset, list_index=list_index)
        

    def my_playlists_tracks(self, pos, user, start=0, max_item=0, offset=0):
        
        if False == self.use_web_api:
            pl = Playlist()
            playlist_tracks = pl.load_tracks(pos, user)
            tracks_unified = playlist_tracks['items']
        else:
            results = self.sp.user_playlist_tracks(user, pos)
            playlist_tracks = results
            while results['next']:
                results = self.sp.next(results)
                playlist_tracks['items'].extend(results['items']) 
        
            tracks = playlist_tracks['items']
            
            #unify track list
            tracks_unified = []
            for track in tracks:
                tracks_unified.append(track['track'])
            
        self._create_track_list(tracks_unified)


    def search_artists(self, search_str = '', offset=0, list_index=1):
        offset = int(offset)
        list_index = int(list_index)
        
        if search_str == '':
            keyboard = Keyboard()
            search_str = keyboard.get_text(heading='Enter Artist')
            if search_str == '':
                exit()
    
        artists, offset = self._search_item(search_str=search_str, type='artists', offset=offset)
        self._create_artist_list(artists['artists'], add=True, mode='search_artists_next', search_str=search_str, offset=offset, list_index=list_index)

    
    def search_albums(self, search_str = '', offset=0, list_index=1):
        offset = int(offset)
        list_index = int(list_index)
        
        if search_str == '':
            keyboard = Keyboard()
            search_str = keyboard.get_text(heading='Enter Album')
            if search_str == '':
                exit()
    
        albums, offset = self._search_item(search_str=search_str, type='albums', offset=offset)
        albums_unified=albums['albums']
           
        #unify albums list
        for album in albums_unified:
            album['tracks'] = {}
            album['tracks']['items'] = []
            album['tracks']['items'].append({'artists': album['artists']})
            #album['tracks']['items'][0]['artists'][0]['name'] = ''
            album['release_date'] = '0000-00-00'

        self._create_album_list(albums_unified, add=True, mode='search_albums_next', search_str=search_str, offset=offset, list_index=list_index)


    def search_tracks(self, search_str = '', offset=0, list_index=1):
        offset = int(offset)
        list_index = int(list_index)
        
        if search_str == '':
            keyboard = Keyboard()
            search_str = keyboard.get_text(heading='Enter Track')
            if search_str == '':
                exit()
                    
        tracks, offset = self._search_item(search_str=search_str, type='tracks', offset=offset)
        self._create_track_list(tracks=tracks['tracks'], add=True, mode='search_tracks_next', search_str=search_str, offset=offset, list_index=list_index)


    def goto_artist(self, artist_id):
        results=self.sp.artists([artist_id])
        artists = results['artists']
        self._create_artist_list(artists, add=True)
    
    
    def goto_album(self, album_id):
        results=self.sp.albums([album_id])
        albums = results['albums']
        self._create_album_list(albums, add=True)


    def show_album_tracks(self, album, icon, album_name=''):
        tracks = []
        results = self.sp.album_tracks(album)
        tracks.extend(results['items'])
        while results['next']:
            results = self.sp.next(results)
            tracks.extend(results['items'])

        #unify track list
        for track in tracks:
            track['album'] = {}
            track['album']['name'] = album_name
            track['album']['id'] = ''
            track['album']['images'] = []
            track['album']['images'].append({'url': icon})
            
        self._create_track_list(tracks, add=True)  
            

    def show_related_artists(self, artist_id):
        results = self.sp.artist_related_artists(artist_id)
        artists = results['artists']
        self._create_artist_list(artists, add=True)
    
        
    def show_artists_toptracks(self, artist_id):
        results = self.sp.artist_top_tracks(artist_id, self.country)
        tracks = results['tracks']
        self._create_track_list(tracks, add=True)    

        
    def show_artist_albums(self, artist_id, offset=0, list_idex=1):
        self._lookup_albums(artist_id, 'album', offset, list_idex)

      
    def show_artist_singles(self, artist_id, offset=0, list_idex=1):
        self._lookup_albums(artist_id, 'single', offset, list_idex)
        
        
    def show_artist_appears_on(self, artist_id, offset=0, list_idex=1):
        self._lookup_albums(artist_id, 'appears_on', offset, list_idex)
        
        
    def show_artist_compilations(self, artist_id, offset=0, list_idex=1):        
        self._lookup_albums(artist_id, 'compilation', offset, list_idex)  
        
        
    def _add_to_list_multiple(self, id_list, type, filename):
        data = HtsptData()
        list = data.load_list(type, filename)
        list_bak = list
        
        dialog = xbmcgui.DialogProgress()
        dialog.create('Adding to list')
        index = 1
        name = ''
               
        for id in id_list:
            
            if dialog.iscanceled()==True:
                return
            
            if type == 'artists':
                results=self.sp.artists([id])
            elif type == 'albums':
                results=self.sp.albums([id])
                name = results['albums'][0]['name']
            elif type == 'tracks':
                results=self.sp.tracks([id])
            else:
                xbmc.log('Hotspot: wrong type %s' % type, log_level)
                return
            
            item = results[type][0]
            if item != None:
                list[type].append(item)
                #if 'true' == self.use_fanart:
                #    fanart = Fanart()
                #    fanart.add_item(item, type)

            progress = ( (index * 100) / len(id_list) )
            dialog.update(progress, name)
            index = index +1
        
        dialog.close()
                
        list[type].sort(key=lambda item:item['name'].lower())
        data.save_list(type, filename, list, list_bak)

    
    def add_to_list(self, id, type, filename):
        data = HtsptData()
        list = data.load_list(type, filename)
        list_bak = list
        
        for item in list[type]:
            if item['id'] == id:
                return
        
        if type == 'artists':
            results=self.sp.artists([id])
        elif type == 'albums':
            results=self.sp.albums([id])
        elif type == 'tracks':
            results=self.sp.tracks([id])
        else:
            xbmc.log('Hotspot: wrong type %s' % type, log_level)
            return
        
        item = results[type][0]
        if item != None:
            list[type].append(item)
            list[type].sort(key=lambda item:item['name'].lower())
            
            self.add_to_resently_list(item, type)
            
            if 'true' == self.use_fanart:
                fanart = Fanart()
                fanart.add_item(item, type)
        else:
            return
        
        data.save_list(type, filename, list, list_bak)
            
    
    
    def remove_from_list(self, id, type, filename, name=''):
        
        dialog = xbmcgui.Dialog()
        retval = dialog.yesno('Remove', 'Remove from %s?' %name)
        
        if True == retval: 
            data = HtsptData()
            list = data.load_list(type, filename)
            list_bak = list
            
            for item in list[type]:
                if item['id'] == id:
                    list[type].remove(item)
            
            data.save_list(type, filename, list, list_bak)
        
            if type == 'tracks' or type == 'artists' or type == 'albums':
                xbmc.executebuiltin('Container.Refresh')


    def queue_track(self, track_id):        
        results = self._lookup_tracks(track_id)
        tracks = results['tracks']
        self._create_track_list(tracks, play=True)
                
        player = xbmc.Player()
        if not player.isPlaying():
            xbmc_pl = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
            player.play(xbmc_pl)


    def play_album(self, album_id, album_image, album_name):
        tracks = []
        results = self.sp.album_tracks(album_id, self.limit)
        tracks.extend(results['items'])
        while results['next']:
            results = self.sp.next(results)
            tracks.extend(results['items'])
        
        xbmc_pl = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        xbmc_pl.clear()

        #unify track list
        for track in tracks:
            track['album'] = {}
            track['album']['name'] = album_name
            track['album']['id'] = album_id
            track['album']['images'] = []
            track['album']['images'].append({'url': album_image})
        
        self._create_track_list(tracks, add=True, play=True) 
        
        player = xbmc.Player()
        player.play(xbmc_pl)


    def play_playlist(self, pos, user):
        if False == self.use_web_api:
            pl = Playlist()
            playlist_tracks = pl.load_tracks(pos, user)
            tracks_unified = playlist_tracks['items']
        else:
            results = self.sp.user_playlist_tracks(user, pos)
            playlist_tracks = results
            while results['next']:
                results = self.sp.next(results)
                playlist_tracks['items'].extend(results['items']) 
        
            tracks = playlist_tracks['items']
            
            #unify track list
            tracks_unified = []
            for track in tracks:
                tracks_unified.append(track['track'])
        
        xbmc_pl = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        xbmc_pl.clear()
        
        self._create_track_list(tracks_unified, play=True)
        
        player = xbmc.Player()
        player.play(xbmc_pl)


    def update_fanart(self, type, filename):
        fanart = Fanart()
        
        if 'artists' == type:
            fanart.update_database(type, filename)
        elif 'albums' == type:
            fanart.update_database(type, filename)
        elif 'tracks' == type:
            fanart.update_database(type, filename)
        elif 'playlists' == type:
            fanart.update_database(type, filename)

    
    def get_artists_from_fanart(self):
        data = HtsptData()
        results_fanart = data.load_list('fanart', 'fanart')
        
        dialog = xbmcgui.DialogProgress()
        dialog.create('Generate Artists list')
        index = 1
        
        #extract artist ids
        artists = []
        dict = results_fanart['mbrainz_ids']
        for key, _ in dict.iteritems():
            results=self.sp.artists([key])
            item = results['artists'][0]
            if item != None:
                artists.append(item)
    
            progress = ( (index * 100) / len(dict) )
            dialog.update(progress, 'Fetching Artist...')
            index = index +1
            
            if 10 == index:
                #break
                pass
        
        artists.sort(key=lambda item:item['name'].lower())
        dialog.close()
        
        self._create_artist_list(artists, add=True)

    