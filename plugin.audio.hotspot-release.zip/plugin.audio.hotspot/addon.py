
import urlparse
import os
import sys
import xbmcaddon

__addon_id__ = 'plugin.audio.hotspot'
addon_cfg = xbmcaddon.Addon(__addon_id__)
__addon_path__ = addon_cfg.getAddonInfo('path')

#Make hotspot, spotipy and requests available
sys.path.insert(0, os.path.join(__addon_path__, "resources/libs/hotspot"))
if os.path.exists(os.path.join(__addon_path__, "resources/libs/hotspot_misc")):
    sys.path.insert(0, os.path.join(__addon_path__, "resources/libs/hotspot_misc"))
else:
    sys.path.insert(0, os.path.join(__addon_path__, "resources/libs/hotspot_utils"))
sys.path.insert(0, os.path.join(__addon_path__, "resources/libs/requests"))
sys.path.insert(0, os.path.join(__addon_path__, "resources/libs/spotipy"))
sys.path.insert(0, os.path.join(__addon_path__, "resources/libs/utils"))
sys.path.insert(0, os.path.join(__addon_path__, "resources/libs/cherrypy"))
sys.path.insert(0, os.path.join(__addon_path__, "resources/libs/six"))

from dispatcher import Dispatcher


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
addon_args = urlparse.parse_qsl(sys.argv[2][1:])
addon_args = dict(addon_args)


dispatcher = Dispatcher(base_url, addon_handle, addon_args)
dispatcher.route()

